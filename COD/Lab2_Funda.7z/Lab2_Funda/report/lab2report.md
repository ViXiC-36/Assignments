# COD Lab 2 Report

PB22111599 杨映川

## T1 寄存器堆设计

实现了读优先寄存器堆的设计。

代码：

>       // READ-PRIORITY
>       module REG_FILE (
>           input                   [ 0 : 0]        clk,
>       
>           input                   [ 4 : 0]        rf_ra0,
>           input                   [ 4 : 0]        rf_ra1,   
>           input                   [ 4 : 0]        rf_wa,
>           input                   [ 0 : 0]        rf_we,
>           input                   [31 : 0]        rf_wd,
>       
>           output                  [31 : 0]        rf_rd0,
>           output                  [31 : 0]        rf_rd1
>       );
>       
>           reg [31 : 0] reg_file [0 : 31];
>       
>           // 用于初始化寄存器
>           integer i;
>           initial begin
>               for (i = 0; i < 32; i = i + 1)
>                   reg_file[i] = 0;
>           end
>           // write except the 0th reg
>           always @(posedge clk) begin
>               if (rf_we && (|rf_wa))
>                   reg_file[rf_wa] <= rf_wd;
>           end
>           // read
>           assign rf_rd0 = reg_file[rf_ra0];
>           assign rf_rd1 = reg_file[rf_ra1];
>       
>       endmodule

使用网页上提供的testbench文件进行仿真后的波形图结果为：
![alt text](image.png)

## T2 ALU设计

代码：
>       `define ADD                 5'B00000        // 0    
>       `define SUB                 5'B00010        // 2
>       `define SLT                 5'B00100        // 4
>       `define SLTU                5'B00101        // 5
>       `define AND                 5'B01001        // 9
>       `define OR                  5'B01010        // a
>       `define XOR                 5'B01011        // b
>       `define SLL                 5'B01110        // d
>       `define SRL                 5'B01111        // f    
>       `define SRA                 5'B10000        // 10
>       `define SRC0                5'B10001        // 11
>       `define SRC1                5'B10010        // 12
>       
>       module ALU (
>           input                   [31 : 0]            alu_src0,
>           input                   [31 : 0]            alu_src1,
>           input                   [ 4 : 0]            alu_op,
>       
>           output      reg         [31 : 0]            alu_res
>       );
>           always @(*) begin
>               case(alu_op)
>                   `ADD  :
>                       alu_res = alu_src0 + alu_src1;
>                   `SUB  :
>                       alu_res = alu_src0 - alu_src1;
>                   `SLT  :
>                       alu_res = (alu_src0[31] ^ alu_src1[31]) ? 
>                                 {{31{0}}, {alu_src0[31]}}       : 
>                                 {{31{0}}, (alu_src0 < alu_src1)};
>                   `SLTU :
>                       alu_res = {{31{0}}, (alu_src0 < alu_src1)};
>                   `AND  :
>                       alu_res = alu_src0 & alu_src1;
>                   `OR   :
>                       alu_res = alu_src0 | alu_src1;
>                   `XOR  :
>                       alu_res = alu_src0 ^ alu_src1;
>                   `SLL  :
>                       alu_res = alu_src0 << alu_src1;
>                   `SRL  :
>                       alu_res = alu_src0 >> alu_src1;
>                   `SRA  :
>                       alu_res = $signed(alu_src0) >>> alu_src1;
>                   `SRC0 :
>                       alu_res = alu_src0;
>                   `SRC1 :
>                       alu_res = alu_src1;
>                   default :
>                       alu_res = 32'H0;
>               endcase
>           end
>       endmodule

使用以下仿真文件：
>       module ALU_tb();
>       //...
>       
>       //Ports
>       reg [31 : 0] src0;
>       reg [31 : 0] src1;
>       reg [ 4 : 0] sel;
>       wire [31 : 0] res;
>       
>       ALU  ALU_inst (
>         .alu_src0(src0),
>         .alu_src1(src1),
>         .alu_op(sel),
>         .alu_res(res)
>       );
>       
>       initial begin
>           src0=32'hfffe; src1=32'hffff; sel=5'H0;
>           repeat(20) begin
>               #20;
>               sel = sel + 1;
>           end
>           #20;
>           sel = 5'd5; // SLTU
>           src0 = 32'hffff_ffff; src1 = 32'hffff_fffe;
>           #20;
>           src0 = 32'h0000_0001; src1 = 32'h0000_0002;
>           #20;
>           src0 = 32'hffff_ffff; src1 = 32'h0000_0000;
>           #20;
>           src0 = 32'h0000_0000; src1 = 32'hffff_ffff;
>           #20;
>           sel = 5'd4; // SLT
>           src0 = 32'hffff_ffff; src1 = 32'hffff_fffe;
>           #20;
>           src0 = 32'h0000_0001; src1 = 32'h0000_0002;
>           #20;
>           src0 = 32'hffff_ffff; src1 = 32'h0000_0000;
>           #20;
>           src0 = 32'h0000_0000; src1 = 32'hffff_ffff;
>           #20;
>           $finish;
>       end
>       //...
>       
>       
>       endmodule

仿真波形为：
![alt text](image-2.png)
![alt text](image-3.png)
![alt text](image-4.png)

## T3 在线计算器

借助ALU构建了一个在线计算器，对5位有符号数进行处理。
代码：
>       module TOP (
>           input                   [ 0 : 0]            clk,
>           input                   [ 0 : 0]            rst,
>       
>           input                   [ 0 : 0]            enable,
>           input                   [ 4 : 0]            in,
>           input                   [ 1 : 0]            ctrl,
>       
>           output                  [ 3 : 0]            seg_data,
>           output                  [ 2 : 0]            seg_an
>       );
>       
>       reg [0:0] res_en;
>       reg [0:0] src0_en;
>       reg [0:0] src1_en;
>       reg [0:0] op_en;
>       
>       reg [4 :0] alu_src0;
>       reg [4 :0] alu_src1;
>       reg [31:0] alu_res;
>       reg [4 :0] alu_op;
>       
>       always @(*) begin
>         if (rst) begin
>           src0_en = 0;
>           src1_en = 0;
>           op_en = 0;
>           res_en = 0;
>         end
>         else begin
>           case (ctrl)
>           2'b00: begin // option of operation
>             if (enable) begin
>               src0_en = 0;
>               src1_en = 0;
>               op_en = 1;
>               res_en = 0;
>             end
>             else begin
>               op_en = 0;
>             end
>           end 
>           2'b01: begin // write src0
>             if (enable) begin
>               src0_en = 1;
>               src1_en = 0;
>               op_en = 0;
>               res_en = 0;
>             end
>             else begin
>               src0_en = 0;
>             end
>           end 
>           2'b10: begin // write src1
>             if (enable) begin
>               src0_en = 0;
>               src1_en = 1;
>               op_en = 0;
>               res_en = 0;
>             end
>             else begin
>               src1_en = 0;
>             end
>           end 
>           2'b11: begin // output the result
>             if (enable) begin
>               src0_en = 0;
>               src1_en = 0;
>               op_en = 0;
>               res_en = 1;
>             end
>             else begin
>               res_en = 0;
>             end
>           end 
>           default:;
>           endcase
>         end
>       end
>       
>       wire [31: 0] cal_res;
>       
>       always @(posedge clk) begin
>         if (src0_en)
>           alu_src0 <= in;
>         else
>           alu_src0 <= alu_src0;
>       end
>       
>       always @(posedge clk) begin
>         if (src1_en)
>           alu_src1 <= in;
>         else
>           alu_src1 <= alu_src1;
>       end
>       
>       always @(posedge clk) begin
>         if (op_en)
>           alu_op <= in;
>         else
>           alu_op <= alu_op;
>       end
>       
>       always @(posedge clk) begin
>         if (res_en)
>           alu_res <= cal_res;
>         else
>           alu_res <= alu_res;
>       end
>       
>       ALU  ALU_inst (
>           .alu_src0({{27{alu_src0[4]}}, {alu_src0}}),
>           .alu_src1({{27{alu_src1[4]}}, {alu_src1}}),
>           .alu_op(alu_op),
>       
>           .alu_res(cal_res)
>         );
>       
>         Segment  Segment_inst (
>           .clk(clk),
>           .rst(rst),
>           .output_data(alu_res),
>       
>           .seg_data(seg_data),
>           .seg_an(seg_an)
>         );
>       
>       
>       endmodule

FPGA实现效果：

* ctrl=00时赋值0（加法运算），并令src0=11111（-1），src1=11110（-2），数码管输出结果为-3

![alt text](image-1.png)

## T4 初始化存储器

使用分布式存储器IP核，导入coe文件后效果：
![alt text](image-5.png)
