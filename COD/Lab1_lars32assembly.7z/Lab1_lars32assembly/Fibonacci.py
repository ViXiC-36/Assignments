Fibonacci = [1, 1]
n = 13
for i in range(1, n - 1):
    Fibonacci.append(int(Fibonacci[-1]) + int(Fibonacci[-2]))
for a in range(0, n):
    Fibonacci[a] = hex(int(Fibonacci[a]))
print(Fibonacci)