# COD Lab 1 Report

PB22111599 杨映川

## T1 Fibonacci数列

使用龙芯汇编语言编写一个计算第N个斐波那契数（1<=N<=30）并将结果储存在寄存器R3中。

代码：

>       li.w r2, 3 #n
>       
>       addi.w a0, r2, 0 #n
>       li.w t0, 1 #f(n-2)
>       li.w t1, 1 #f(n-1)
>       li.w t2, 1 #f(n)
>       
>       slti a1, a0, 3
>       beq a1, t0, done
>       addi.w a0, a0, -2
>       
>       loop:
>       beq a0, zero, done
>       addi.w a0, a0, -1
>       add.w t2, t0, t1
>       addi.w t0, t1, 0
>       addi.w t1, t2, 0
>       b loop
>       
>       done:
>       addi.w r3, t2, 0

结果：
当n=13时，输出为0xe9
![alt text](image.png)

## T2 Fibonacci数列大整数处理

为每个数据增加一个寄存器来储存高32位。

代码：
>       li.w r2, 80     #n
>       
>       addi.w t8, r2, 0    #n
>       li.w a0, 0          #f(n-2) higher 32 bits
>       li.w t0, 1          #f(n-2) lower 32 bits
>       li.w a1, 0          #f(n-1) higher 32 bits
>       li.w t1, 1          #f(n-1) lower 32 bits
>       li.w a2, 0          #f( n ) higher 32 bits
>       li.w t2, 1          #f( n ) lower 32 bits
>       
>       # (N<3)
>       slti a1, t8, 3
>       beq a1, t0, done
>       # (N>=3)
>       addi.w t8, t8, -2
>       
>       # loop calculating
>       loop:
>       beq t8, zero, done
>       addi.w t8, t8, -1
>       # Add lower 32 bits
>       add.w t2, t0, t1
>       # Check for overflow
>       sltu t6, t2, t1 #??
>       # Add higher 32 bits
>       add.w a2, a0, a1
>       # Include carry
>       add.w a2, a2, t6
>       # Update f(n-1) & f(n-2)
>       addi.w t0, t1, 0
>       addi.w a0, a1, 0
>       addi.w t1, t2, 0
>       addi.w a1, a2, 0
>       b loop
>       
>       done:
>       addi.w r4, t2, 0
>       addi.w r3, a2, 0

结果：
当n=80时，输出为高位0x533163，低位0xef0321e5.
![alt text](image-1.png)

## T3 导出 COE 文件

导出T2的代码段，内容如下：
>       memory_initialization_radix=16;
>       memory_initialization_vector=
>       03814002,
>       02800054,
>       03800004,
>       0380040c,
>       03800005,
>       0380040d,
>       03800006,
>       0380040e,
>       02000e85,
>       580034ac,
>       02bffa94,
>       58002e80,
>       02bffe94,
>       0010358e,
>       0012b5d2,
>       00101486,
>       001048c6,
>       028001ac,
>       028000a4,
>       028001cd,
>       028000c5,
>       53ffdbff,
>       028001c4,
>       028000c3,
