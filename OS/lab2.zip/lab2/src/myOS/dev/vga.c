/*
 * 本文件实现vga的相关功能，清屏和屏幕输出
 * clear_screen和append2screen必须按照如下借口实现
 * 可以增加其他函数供clear_screen和append2screen调用
 */
extern void outb (unsigned short int port_to, unsigned char value);
extern unsigned char inb(unsigned short int port_from);
//VGA字符界面规格：25行80列
//VGA显存初始地址为0xB8000
#define VGA_WIDTH 80
#define VGA_HEIGHT 25
#define SEGGAL 0x07 // board/character

/* 0 - 黑色 (Black)
 * 1 - 蓝色 (Blue)
 * 2 - 绿色 (Green)
 * 3 - 青色 (Cyan)
 * 4 - 红色 (Red)
 * 5 - 洋红色/品红色 (Magenta)
 * 6 - 棕色 (Brown)
 * 7 - 浅灰色 (Light Gray)
 * 8 - 深灰色 (Dark Gray)
 * 9 - 亮蓝色 (Light Blue)
 * a - 亮绿色 (Light Green)
 * b - 亮青色 (Light Cyan)
 * c - 亮红色 (Light Red)
 * d - 亮洋红色/亮品红色 (Light Magenta)
 * e - 黄色 (Yellow)
 * f - 白色 (White)
 */

short cur_line=0;
short cur_column=0;//当前光标位置
char * vga_init_p=(char *)0xB8000;


void update_cursor(void){//通过当前行值cur_cline与列值cur_column回写光标
	//填写正确的内容 
	//calculate the offset in 1-dim
	unsigned short int position = (cur_line * 80) + cur_column;
	//lower 8bit
	outb(0x3D4, 0x0F);
	outb(0x3D5, (unsigned char)(position  & 0xFF));
	//higher 8bit
	outb(0x3D4, 0x0E);
	outb(0x3D5, (unsigned char)((position >> 8) & 0xFF));
}

short get_cursor_position(void){//获得当前光标，计算出cur_line和cur_column的值
	//填写正确的内容    
	unsigned short int position;
	//lower 8bit
	outb(0x03d4, 0x0e);
	position = inb(0x3d5) << 8;
	//higher 8bit
	outb(0x3d4, 0x0f);
	position += inb(0x3d5);

	cur_line = position / VGA_WIDTH;
	cur_column = position % VGA_WIDTH;

	return position;
}


void clear_screen(void) {
	//填写正确的内容    
	for (int i = 0; i < VGA_HEIGHT * VGA_WIDTH; i++)
	{
		vga_init_p[i * 2] = ' ';
		vga_init_p[i * 2 + 1] = SEGGAL;
	}
	cur_line = 0;
	cur_column = 0;
	update_cursor();
}

void scroll_screen()
{
	// Every former line ascend 1 line
	for (int line = 1; line < VGA_HEIGHT; line++)
	{
		for (int col = 0; col < VGA_WIDTH; col++)
		{
			const int srcOffset = ((line * VGA_WIDTH) + col) * 2;
			const int dstOffset = (((line - 1) * VGA_WIDTH) + col) * 2;
			vga_init_p[dstOffset] = vga_init_p[srcOffset];
			vga_init_p[dstOffset + 1] = vga_init_p[srcOffset + 1];
		}
	}

	//Clear the last line
	for (int col = 0; col < VGA_WIDTH; col++)
	{
		const int offset = (((VGA_HEIGHT - 1) * VGA_WIDTH) + col) * 2;
		vga_init_p[offset] = ' ';
		vga_init_p[offset + 1] = SEGGAL;
	}
}

void append2screen(char *str,int color){ 
	//填写正确的内容    
	int i = 0;
	while (str[i] != 0)
	{	//new line
		if (str[i] == '\n')
		{
			cur_line++;
			cur_column = 0;
		}
		else
		{// string into VGA
			const int offset = ((cur_line * VGA_WIDTH) + cur_column) * 2;
			vga_init_p[offset] = str[i];
			vga_init_p[offset + 1] = color;
			cur_column++;
			if (cur_column >= VGA_WIDTH)
			{	// new line
				cur_line++;
				cur_column = 0;
			}
		}
		
		// Check whether to scroll the screen
		if (cur_line >= VGA_HEIGHT)
		{
			scroll_screen();
			cur_line = VGA_HEIGHT - 1;
		}

		i++;
	}
	update_cursor();
}


