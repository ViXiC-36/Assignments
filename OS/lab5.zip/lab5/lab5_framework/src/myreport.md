# OS Lab 5 Report
PB22111599 杨映川

## 软件框图
![alt text](image.png)

此次实验新增功能：上下文切换、任务管理和任务调度模块。

## 主流程

1. multibootHeader.s -> start32.s -> osStart.c
2. 初始化任务管理器，创建initTsk和队列，进行FCFS调度
3. 进入用户程序myMain，创建tsk0，tsk1，tsk2用于测试，创建shelltsk，按照FCFS依次执行各个任务。

## 主要功能模块及其实现

### #1 myTCB 的数据结构
* stack：为 myTCB 开辟栈空间（本次实验使用 CTX SW 来进行上下文切换，而为了实现上下文切换，我们需要维护每个myTCB的stack空间）。
* stkTop：栈顶指针（本次实验使用CTXSW来进行上下文切换，而为了实现上下文切换，我们需要维护每个myTCB的栈顶指针）。
* TSK State：进程的状态 (进程池中的 TCB 一共有四种状态：当前进程已经进入就绪队列中、当前进程还未进入就绪队列中、当前进程正在运行、进程池中的TCB为空未进行分配)。
* TSK ID：进程的ID。
* task entrance：函数入口（本次实验中，我们通过 CTX SW 来进行上下文切换，而不是这个函数入口）。
* nextTCB：对于空闲的TCB，我们将空闲的TCB进行链表维护。对于处于就绪队列中的TCB我们也进行链表维护。

代码：
```C
typedef struct myTCB {
     unsigned long *stkTop;        /* 栈顶指针 */
     unsigned long stack[STACK_SIZE];      /* 开辟了一个大小为STACK_SIZE的栈空间 */  
     unsigned long TSK_State;   /* 进程状态 */
     unsigned long TSK_ID;      /* 进程ID */ 
     void (*task_entrance)(void);  /*进程的入口地址*/
     struct myTCB * nextTCB;           /*下一个TCB*/
} myTCB;
```

### #2 就绪队列的维护

为管理任务调度，还需实现一个就绪队列，它的元素是myTCB。对于FCFS，实现一个FIFO队列，将任务按照到达时间的顺序插入其中。

代码：
```C
//就绪队列的结构体
typedef struct rdyQueueFCFS{
     myTCB * head;
     myTCB * tail;
     myTCB * idleTsk;
} rdyQueueFCFS;

rdyQueueFCFS rqFCFS;

//初始化就绪队列（需要填写）
void rqFCFSInit(myTCB* idleTsk) {//对rqFCFS进行初始化处理
     rqFCFS.head = (void *)0;
     rqFCFS.tail = (void *)0;
     rqFCFS.idleTsk = idleTsk;
}

//如果就绪队列为空，返回True（需要填写）
int rqFCFSIsEmpty(void) {//当head和tail均为NULL时，rqFCFS为空
     int flag = (rqFCFS.head == (void *)0) && (rqFCFS.tail == (void *)0);
     return flag;
}

//获取就绪队列的头结点信息，并返回（需要填写）
myTCB * nextFCFSTsk(void) {//获取下一个Tsk
     if (rqFCFSIsEmpty())
          return rqFCFS.idleTsk;
     else
          return rqFCFS.head;
}

//将一个未在就绪队列中的TCB加入到就绪队列中（需要填写）
void tskEnqueueFCFS(myTCB *tsk) {//将tsk入队rqFCFS
     if (rqFCFSIsEmpty()){
          rqFCFS.head = tsk;
          rqFCFS.tail = tsk;
     }
     else{
          rqFCFS.tail->nextTCB = tsk;
          rqFCFS.tail = tsk;
     }
}

//将就绪队列中的TCB移除（需要填写）
void tskDequeueFCFS(myTCB *tsk) {//rqFCFS出队
     if (rqFCFSIsEmpty())
          return;
     else{
          if (rqFCFS.head == rqFCFS.tail){//Queue empty
               rqFCFS.head = (void *)0;
               rqFCFS.tail = (void *)0;
          }
          else{
               rqFCFS.head = rqFCFS.head->nextTCB;
          }
     }
}
```

### #3 任务池中任务的维护

需要实现任务的创建和销毁两种原语。我们通过静态的方式管理任务池：提前分配好一定数量（可自行配置）的myTCB，存放在数组（任务池）中。创建任务时，直接从任务池中取出一个空闲的myTCB；销毁时则将其重新设置为空闲，释放回任务池。
* `void tskStart(myTCB *tsk)` ：创建好任务后，需要启动任务时，调用此原语。传入参数是任务的TCB，原语行为是启动任务，将任务状态设置为就绪，然后插入就绪队列。
* `void tskEnd()` ：此原语在某个任务执行结束后被调用。其行为是销毁当前任务，并通知操作系统可以进行调度、开始下一个任务。

代码：
```C
//进程池中一个未在就绪队列中的TCB的开始（不需要填写）
void tskStart(myTCB *tsk){
     tsk->TSK_State = TSK_RDY;
     //将一个未在就绪队列中的TCB加入到就绪队列
     tskEnqueueFCFS(tsk);
}

//进程池中一个在就绪队列中的TCB的结束（不需要填写）
void tskEnd(void){
     //将一个在就绪队列中的TCB移除就绪队列
     tskDequeueFCFS(currentTsk);
     //由于TCB结束，我们将进程池中对应的TCB也删除
     destroyTsk(currentTsk->TSK_ID);
     //TCB结束后，我们需要进行一次调度
     schedule();
}

//以tskBody为参数在进程池中创建一个进程，并调用tskStart函数，将其加入就绪队列（需要填写）
int createTsk(void (*tskBody)(void)){//在进程池中创建一个进程，并把该进程加入到rqFCFS队列中
     if (!firstFreeTsk)
          return -1;
     else{
          myTCB * newtsk = firstFreeTsk;
          firstFreeTsk = firstFreeTsk->nextTCB;
          newtsk->task_entrance = tskBody;
          stack_init(&newtsk->stkTop, tskBody);
          tskStart(newtsk);
          return newtsk->TSK_ID;
     }
}

//以takIndex为关键字，在进程池中寻找并销毁takIndex对应的进程（需要填写）
void destroyTsk(int takIndex) {//在进程中寻找TSK_ID为takIndex的进程，并销毁该进程
     tcbPool[takIndex].task_entrance = (void *)0;
     tcbPool[takIndex].TSK_State = TSK_NONE;
     tcbPool[takIndex].nextTCB = firstFreeTsk;
     firstFreeTsk = &tcbPool[takIndex];
}
```

## 运行结果
![alt text](20e582372d8a30952f3d57bc0060a1d2.png)

## 源代码说明
```
└───src
    ├───.vscode
    ├───multibootheader
    ├───myOS
    │   ├───dev
    │   ├───i386
    │   ├───include
    │   ├───kernel
    │   │   └───mem
    │   ├───lib
    │   └───printk
    ├───output
    │   ├───multibootheader
    │   ├───myOS
    │   │   ├───dev
    │   │   ├───i386
    │   │   ├───kernel
    │   │   │   └───mem
    │   │   ├───lib
    │   │   └───printk
    │   └───userApp
    └───userApp
```

## 代码布局（地址空间）说明

本次的代码布局（地址空间）与前几次实验相同：

| Offset | field      |  Note | 
| ------------------- | ----------------- | -----|
| 1M                   | .text              | 代码段   |
| ALIGN(16)           | .data              | 数据段   |
| ALIGN(16)           | .bss             | bss段   |
| ALIGN(16)           |               | _end 空闲内存起始地址 |

> ALIGN(16)表示起始地址按16字节对齐。


## 思考题
* **在上下文切换的现场维护中，pushf和popf对应，pusha 和popa 对应，call 和 ret 对应，但是为什么CTSSW函数中只有ret而没有call呢？**

CTSSW函数：
```C
CTX_SW:
    pushf
    pusha
    movl prevTSK_StackPtr, %eax
    movl %esp, (%eax)
    movl nextTSK_StackPtr, %esp
    popa
    popf
    ret
```

进程的上下文包括四部分：
1. 通用寄存器 eax, ecx, edx, ebx, esp, ebp, esi, edi
2. 状态寄存器
3. PC寄存器 eip
4. 栈。
上下文切换即保存前一个任务的上下文，读取后一个任务的上下文。当需要进行上下文切换时会调用CTS_SW函数。

CTS_SW 函数中只有ret而没有call的原因：外部调用该函数时**PC寄存器的值已经被自动压栈了**，而最后用ret是为了把该值出栈。

* **谈一谈你对`stack_init`函数的理解。**

`stack_init`函数:
```C
void stack_init(unsigned long **stk, void (*task)(void)){
     *(*stk)-- = (unsigned long) 0x08;       //高地址
     *(*stk)-- = (unsigned long) task;       //EIP
     *(*stk)-- = (unsigned long) 0x0202;     //FLAG寄存器

     *(*stk)-- = (unsigned long) 0xAAAAAAAA; //EAX
     *(*stk)-- = (unsigned long) 0xCCCCCCCC; //ECX
     *(*stk)-- = (unsigned long) 0xDDDDDDDD; //EDX
     *(*stk)-- = (unsigned long) 0xBBBBBBBB; //EBX

     *(*stk)-- = (unsigned long) 0x44444444; //ESP
     *(*stk)-- = (unsigned long) 0x55555555; //EBP
     *(*stk)-- = (unsigned long) 0x66666666; //ESI
     *(*stk)   = (unsigned long) 0x77777777; //EDI
}
```
该函数用于初始化栈空间，从而进行上下文切换操作。由于栈是反向分配的，故指针一直--。

* **myTCB结构体定义中的`stack[STACKSIZE]`的作用是什么？`BspContextBase[STACK SIZE]`的作用又是什么？**

`stack[STACKSIZE]`开辟了一个栈空间。`BspContextBase[STACK SIZE]`是系统栈，为调度操作提供操作空间。

* **`prevTSK_ StackPtr`是一级指针还是二级指针？为什么？**

是二级指针，即指向指针的指针。由定义即可知。
```C
unsigned long **prevTSK_StackPtrAddr;
```