#ifndef __WALLCLOCK_H__
#define __WALLCLOCK_H__

void setWallClock(int HH,int MM,int SS);
void getWallClock(int *HH,int *MM,int *SS);

#endif
