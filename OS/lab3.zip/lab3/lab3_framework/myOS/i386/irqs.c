#include "myPrintk.h" 
void ignoreIntBody(void){
    myPrintk(0x07,"Unknown interrupt\n\0");
}
