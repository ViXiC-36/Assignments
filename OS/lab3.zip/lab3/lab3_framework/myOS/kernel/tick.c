#include "wallClock.h"
int system_ticks=0;
int HH=13,MM=13,SS=0;
#define TICKS_PER_SEC 100

void tick(void){
	system_ticks++;
	//TODO 你需要填写它
	if (system_ticks >= TICKS_PER_SEC)
	{
		system_ticks = 0;
		SS++;
		if (SS >= 60)
		{
			SS = 0;
			MM++;
			if (MM >= 60)
			{
				MM = 0;
				HH++;
				if (HH >= 24)
				{
					HH = 0;
				}
			}
		}
	}
	setWallClock(HH,MM,SS);
	return;
}

