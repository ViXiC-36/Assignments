#include "vga.h"
#include "io.h"
#include "uart.h"

int current_h;
int current_m;
int current_s;

void setWallClock(int HH,int MM,int SS){
	//TODO 你需要填写它
	current_h = HH;
	current_h = MM;
	current_s = SS;
	char timeString[9] = {HH/10+'0', HH%10+'0', ':', 
						  MM/10+'0', MM%10+'0', ':', 
						  SS/10+'0', SS%10+'0', 0}; // HH:MM:SS
	append2location(24, 71, timeString, 0x07);
}

void getWallClock(int *HH,int *MM,int *SS){
	//TODO 你需要填写它
	*HH = current_h;
	*MM = current_m;
	*SS = current_s;
}
