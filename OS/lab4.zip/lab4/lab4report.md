# OS Lab 4 Report
PB22111599 杨映川

## 软件框图
![alt text](image.png)

### 概述：
1. 基于IO端口实现VGA和串口的交互程序、i8259和i8253的初始化；
2. 通过userinterface.h这一接口实现shell的功能。本次实验增加了动态增加命令以及内存管理程序。

## 主流程
1. 从multibootHeader.s开始执行程序；
2. 跳转至start32.s, 通过汇编搭建stack和heap，初始化bss段和中断描述符表idt；
3. 跳转到osStart.c, 开始运行myOS，初始化i8259和i8253，开启中断以实现时钟中断；
4. 运行用户程序函数myMain初始化shell，获得相应命令。初始化内存管理算法测试样例，最终启动shell。

## 主要功能模块和实现
### 内存检测算法
在实现内存分区管理算法前，先检测可用内存的范围，可用内存指可正常读写的内存大小。默认内存从1M处开始。依次检测grainsize的各个字节，直到检测结束并打印检测结果。（此处为了使检测结果正常显示便注释掉了myMain里面的清屏函数）

代码：
```C
void memTest(unsigned long start, unsigned long grainSize){
	// TODO
	/*功能：检测算法
		这一个函数对应实验讲解ppt中的第一大功能-内存检测。
		本函数的功能是检测从start开始有多大的内存可用，具体算法参照ppt检测算法的文字描述
	注意点三个：
	1、覆盖写入和读出就是往指针指向的位置写和读，不要想复杂。
	  (至于为什么这种检测内存的方法可行大家要自己想一下)
	2、开始的地址要大于1M，需要做一个if判断。
	3、grainsize不能太小，也要做一个if判断
	*/
    if (start < 0x100000) 
		start = 0x100000;

	if (grainSize < 2)
		grainSize = 2;

	unsigned long addr = start;
	unsigned short data;
	unsigned short *addr_first_2_bits;
	unsigned short *addr_last__2_bits;
	unsigned short test_data1 = 0xAA55;
	unsigned short test_data2 = 0x55AA;
	int fail = 0;
	pMemStart = start;
	pMemSize = 0;

	while (!fail){
		fail = 0;

		addr_first_2_bits = (unsigned short *)addr;
		addr_last__2_bits = (unsigned short *)(addr + grainSize - 2);

		// to first 2 bits
		data = *addr_first_2_bits; // read & cache
		*addr_first_2_bits = test_data1; // write 0xAA55
		if (*addr_first_2_bits != test_data1) 
			fail = 1; // write success ?
		*addr_first_2_bits = test_data2; // write 0x55AA
		if (*addr_first_2_bits != test_data2) 
			fail = 1; // write success ?
		*addr_first_2_bits = data; // write back

		// to last 2 bits
		data = *addr_last__2_bits; // read & cache
		*addr_last__2_bits = test_data1; // write 0xAA55
		if (*addr_last__2_bits != test_data1) 
			fail = 1; // write success ?
		*addr_last__2_bits = test_data2; // write 0x55AA
		if (*addr_last__2_bits != test_data2) 
			fail = 1; // write success ?
		*addr_last__2_bits = data; // write back

		if (!fail) {
			addr += grainSize;
			pMemSize += grainSize;
		}
	}

	myPrintk(0x7,"MemStart: %x  \n", pMemStart);
	myPrintk(0x7,"MemSize:  %x  \n", pMemSize);
	
}
```
流程：核验写入的数据与读出的数据是否一致，即先写后读，如果一致
就认为内存可用.同时对数据进行缓存，方式写覆盖。

### 等大小内存分区管理
使用句柄数据结构。创建一个eFPartition结构体，然后再对除去eFPartition存储空间后的剩余空间开辟若干连续的空闲内存块，将他们连起来构成一个链。为内存块之间添加隔离带EEB，以避免小范围的溢出带来的问题。

代码：
```C
unsigned long align4(unsigned long n){
	if (n & 1) n += 1; // 消除最低位
	if (n & 2) n += 2; // 消除次低位
	return n;
}


unsigned long eFPartitionTotalSize(unsigned long perSize, unsigned long n){
	// TODO
	/*功能：计算占用空间的实际大小，并将这个结果返回
	1. 根据参数persize（每个大小）和n个数计算总大小，注意persize的对齐。
		例如persize是31字节，你想8字节对齐，那么计算大小实际代入的一个块的大小就是32字节。
	2. 同时还需要注意“隔离带”EEB的存在也会占用4字节的空间。
		typedef struct EEB {
			unsigned long next_start;
		}EEB;	
	3. 最后别忘记加上eFPartition这个数据结构的大小，因为它也占一定的空间。

	*/
	if (perSize <= 0)
		return 0;

	unsigned long perSize_align = align4(perSize);
	return perSize * n + eFPartition_size + EEB_size * n;
}

unsigned long eFPartitionInit(unsigned long start, unsigned long perSize, unsigned long n){
	// TODO
	/*功能：初始化内存
	1. 需要创建一个eFPartition结构体，需要注意的是结构体的perSize不是直接传入的参数perSize，需要对齐。结构体的next_start也需要考虑一下其本身的大小。
	2. 就是先把首地址start开始的一部分空间作为存储eFPartition类型的空间
	3. 然后再对除去eFPartition存储空间后的剩余空间开辟若干连续的空闲内存块，将他们连起来构成一个链。注意最后一块的EEB的nextstart应该是0
	4. 需要返回一个句柄，也即返回eFPartition *类型的数据
	注意的地方：
		1.EEB类型的数据的存在本身就占用了一定的空间。
	*/
	if (perSize <= 0)
		return 0;

	unsigned long perSize_align = align4(perSize);

	eFPartition *efp = (eFPartition *)start;
	efp->totalN = n;
	efp->perSize = perSize_align;
	unsigned long addr = start + eFPartition_size;
	efp->firstFree = addr;
	
	// 等空间划分
	EEB *block;
	for (int i = 0; i < n; i++){
		block = (EEB *)addr;
		addr += perSize_align;
		block->next_start = addr;
	}
	block->next_start = 0;

	return start;

}

// 空间分配
unsigned long eFPartitionAlloc(unsigned long EFPHandler){
	// TODO
	/*功能：分配一个空间
	1. 本函数分配一个空闲块的内存并返回相应的地址，EFPHandler表示整个内存的首地址
	2. 事实上EFPHandler就是我们的句柄，EFPHandler作为eFPartition *类型的数据，其存放了我们需要的firstFree数据信息
	3. 从空闲内存块组成的链表中拿出一块供我们来分配空间，并维护相应的空闲链表以及句柄
	注意的地方：
		1.EEB类型的数据的存在本身就占用了一定的空间。

	*/
	eFPartition *efp = (eFPartition *)EFPHandler;

	// no free block
	if (!efp->firstFree) return 0;

	EEB *block = (EEB *)efp->firstFree;
	efp->firstFree = block->next_start;

	// 返回分配内存的起始地址
	return (unsigned long)block;
	
}


unsigned long eFPartitionFree(unsigned long EFPHandler,unsigned long mbStart){
	// TODO
	/*功能：释放一个空间
	1. mbstart将成为第一个空闲块，EFPHandler的firstFree属性也需要相应大的更新。
	2. 同时我们也需要更新维护空闲内存块组成的链表。
	
	*/
	if (mbStart < EFPHandler + eFPartition_size) 
		return 0;

	eFPartition *efp = (eFPartition *)EFPHandler;

	// illegal mbStart
	if (mbStart > EFPHandler + eFPartitionTotalSize(efp->perSize, efp->totalN)) 
		return 0;

	unsigned long addr = efp->firstFree;
	unsigned long pre_addr = 0;
	unsigned long next_addr = 0;
	EEB *block;

	// find the pre_addr and next_addr
	while (addr){
		block = (EEB *)addr;
		if (addr < mbStart)
			pre_addr = addr;
		else if (addr > mbStart){
			next_addr = addr;
			break;
		}
		addr = block->next_start;
	}

	//free
	block = (EEB *)mbStart;
	if (next_addr)
		block->next_start = next_addr;
	else // no more blocks behind
		block->next_start = 0;

	if (pre_addr){
		EEB *pre_block = (EEB *)pre_addr;
		pre_block->next_start = mbStart;
	}
	else // no more blocks before
		efp->firstFree = mbStart;

	return 1;
	
}

```

### 动态大小内存分区管理
使用句柄数据结构。初始化时，用户传入分区大小并在其上建立句柄数据结构，然后将剩余空间划分为一个内存块，用一个EMB管理。请求分配时，从这个内存块中划分出相应大小的一块。回收时，需考虑回收的块是否能与前后相邻的空闲空间合并。

代码：
```C
unsigned long dPartitionInit(unsigned long start, unsigned long totalSize){
	// TODO
	/*功能：初始化内存。
	1. 在地址start处，首先是要有dPartition结构体表示整个数据结构(也即句柄)。
	2. 然后，一整块的EMB被分配（以后使用内存会逐渐拆分），在内存中紧紧跟在dP后面，然后dP的firstFreeStart指向EMB。
	3. 返回start首地址(也即句柄)。
	注意有两个地方的大小问题：
		第一个是由于内存肯定要有一个EMB和一个dPartition，totalSize肯定要比这两个加起来大。
		第二个注意EMB的size属性不是totalsize，因为dPartition和EMB自身都需要要占空间。
	
	*/
	if (totalSize <= dPartition_size + EMB_size)
		return 0;

	dPartition *dp = (dPartition *)start;
	dp->size = totalSize;
	dp->firstFreeStart = start + dPartition_size;

	// 
	EMB *block = (EMB *)dp->firstFreeStart;
	block->size = totalSize - dPartition_size;
	block->nextStart = 0;

	return start;

}


void dPartitionWalkByAddr(unsigned long dp){
	// TODO
	/*功能：本函数遍历输出EMB 方便调试
	1. 先打印dP的信息，可调用上面的showdPartition。
	2. 然后按地址的大小遍历EMB，对于每一个EMB，可以调用上面的showEMB输出其信息

	*/
	dPartition *handler = (dPartition *)dp;
	showdPartition(handler);

	unsigned long addr = handler->firstFreeStart;
	EMB *block;
	while (addr){
		block = (EMB *)addr;
		showEMB(block);
		addr = block->nextStart;
	}
}


//=================firstfit, order: address, low-->high=====================
/**
 * return value: addr (without overhead, can directly used by user)
**/

unsigned long dPartitionAllocFirstFit(unsigned long dp, unsigned long size){
	// TODO
	/*功能：分配一个空间
	1. 使用firstfit的算法分配空间，
	2. 成功分配返回首地址，不成功返回0
	3. 从空闲内存块组成的链表中拿出一块供我们来分配空间(如果提供给分配空间的内存块空间大于size，我们还将把剩余部分放回链表中)，并维护相应的空闲链表以及句柄
	注意的地方：
		1.EMB类型的数据的存在本身就占用了一定的空间。

	*/
	if (size <= 0) 
		return 0;


	dPartition *handler = (dPartition *)dp;
	if (!handler->firstFreeStart) 
		return 0;

	unsigned long size_align = align8(size);
	unsigned long addr = handler->firstFreeStart;
	unsigned long pre_addr = 0;
	EMB *block;
	EMB *pre_block;

	while (addr){
		block = (EMB *)addr;
		pre_block = (EMB *)pre_addr;

		if (block->size >= size_align + sizeof(unsigned long) && 
			block->size <= size_align + sizeof(unsigned long) + EMB_size){
			if (pre_block == 0)
				handler->firstFreeStart = block->nextStart;
			else
				pre_block->nextStart = block->nextStart;
			return addr + sizeof(unsigned long);
		}
		else if (block->size > size_align + sizeof(unsigned long) + EMB_size){
			unsigned long new_addr_node = addr + sizeof(unsigned long) + size_align;
			EMB *new_block = (EMB *)(new_addr_node);
			new_block->size = block->size - size_align - sizeof(unsigned long);
			new_block->nextStart = block->nextStart;
			block->size -= new_block->size;

			if (pre_block == 0)
				handler->firstFreeStart = new_addr_node;
			else
				pre_block->nextStart = new_addr_node;

			return addr + sizeof(unsigned long);
		}
	
		pre_addr = addr;
		addr = block->nextStart;
	}

	return 0; // no suitable block

}

// 
unsigned long dPartitionFreeFirstFit(unsigned long dp, unsigned long start){
	// TODO
	/*功能：释放一个空间
	1. 按照对应的fit的算法释放空间
	2. 注意检查要释放的start~end这个范围是否在dp有效分配范围内
		返回1 没问题
		返回0 error
	3. 需要考虑两个空闲且相邻的内存块的合并
	
	*/

	start -= sizeof(unsigned long);

	if (start < dp + dPartition_size) 
		return 0;

	dPartition *handler = (dPartition *)dp;

	if (start >= dp + handler->size)
		return 0;
	
	unsigned long addr = handler->firstFreeStart;
	unsigned long pre_addr = 0;
	unsigned long next_addr = 0;
	EMB *block;

	while (addr){
		block = (EMB *)addr;
		if (addr < start)
			pre_addr = addr;
		else if (addr > start){
			next_addr = addr;
			break;
		}
		addr = block->nextStart;
	}

	// free
	block = (EMB *)start;
	if (next_addr) {
		if (next_addr == start + block->size){
			EMB *next_block = (EMB *)next_addr;
			block->size += next_block->size;
			block->nextStart = next_block->nextStart;
		}
		else
			block->nextStart = next_addr;
	}
	else
		block->nextStart = 0;

	if (pre_addr){
		EMB *pre_block = (EMB *)pre_addr;
		if (start == pre_addr + pre_block->size){
			pre_block->size += block->size;
			pre_block->nextStart = block->nextStart;
		}
		else
			pre_block->nextStart = start;
	}
	else
		handler->firstFreeStart = start;

	return 1;
}


// 进行封装，此处默认firstfit分配算法，当然也可以使用其他fit，不限制。
unsigned long dPartitionAlloc(unsigned long dp, unsigned long size){
	return dPartitionAllocFirstFit(dp,size);
}

unsigned long dPartitionFree(unsigned long	 dp, unsigned long start){
	return dPartitionFreeFirstFit(dp,start);
}
```

### Shell动态注册命令
使用链表来储存所有的命令，借助写好的malloc函数来动态添加命令。

代码：
```C
void addNewCmd(	unsigned char *cmd, 
		int (*func)(int argc, unsigned char **argv), 
		void (*help_func)(void), 
		unsigned char* description){
	// TODO
    /*功能：增加命令
    1. 使用malloc创建一个cmd的结构体，新增命令。
    2. 同时还需要维护一个表头为ourCmds的链表。
    */
    struct cmd *newCmd = (struct cmd *)malloc(cmd_size);
    char *n_cmd = (char *)malloc(strlen(cmd)+1);
    char *n_description = (char *)malloc(strlen(description)+1);
    if (!newCmd || !n_cmd || !n_description) {
        myPrintf(0x7,"malloc failed\n");
        return;
    }
    
    mystrcpy(cmd, newCmd->cmd, strlen(cmd)+1);
    newCmd->func = func;
    newCmd->help_func = help_func;
    mystrcpy(description, newCmd->description, strlen(description)+1);

    // add to ourCmds
    newCmd->nextCmd = ourCmds;
    ourCmds = newCmd;

}
```

## 源代码说明
### 目录组织
![alt text](image-13.png)

### Makefile
![alt text](image-14.png)

## 代码布局说明
| Offset | field      |  Note | 
| ------------------- | ----------------- | -----|
| 1M                   | .text              | 代码段   |
| ALIGN(16)           | .data              | 数据段   |
| ALIGN(16)           | .bss             | bss段   |
| ALIGN(16)           |               | _end 空闲内存起始地址 |

## 编译与运行结果
使用`./source2img`命令编译并连接到VGA和串口。
### 系统启动和可用内存测试
![alt text](image-7.png)
### 命令动态注册测试和malloc测试
依次输入`cmd`，`testMalloc1`, `testMalloc2`
详细解释：分配两个buffer，分别填充不同的内容
![alt text](image-8.png)
### dPartition测试
1. 输入`testdP1`
详细：创建一个dPartition，总大小为0x100，之后分别尝试在其上分配0x10，0x20，0x40，etc.大小的EMB，再反过来做一次。
![alt text](image-9.png)
结果是符合预期的，因为可用空间是小于0x100的
2. 输入`testdP2`
详细：创建一个dPartition，总大小为0x100, 可用大小为0xf8, 并依次分配ABC三个块，然后按照ABC的顺序收回。
![alt text](image-15.png)
![alt text](image-16.png)
![alt text](image-10.png)
3. 输入`testdP3`
详细：创建一个新的dPartition，总大小为0x100，之后在其上依次分配ABC三个块，然后按照CBA的顺序收回。
![alt text](image-11.png)

### eFPartition测试
输入`testeFP`
详细：先malloc一块0x8c大小的内存块，初始化为合适大小，划分为4个块。之后用`eFPartitionAlloc`请求分配五次，前四次A、B、C、D都成功，最后一次E失败。这是符合预期的。然后分别释放A、B、C、D块。
![alt text](image-12.png)
### maxMallocSizeNow测试
输入`maxMallocSizeNow`
详细：通过迭代增大分配空间直至测试出此时可用的最大malloc空间
![alt text](image-6.png)


## Debugging Problems
1. 一开始执行测试样例`maxMallocSizeNow`时会进入死循环，检查后发现是因为对跳出循环判断会造成影响的变量没有正常的减少。
