#include "../../include/myPrintk.h"
#include "../../include/mem.h"

//dPartition 是整个动态分区内存的数据结构
typedef struct dPartition{
	unsigned long size; // total size
	unsigned long firstFreeStart; 
} dPartition;	//共占8个字节

#define dPartition_size ((unsigned long)0x8)

void showdPartition(struct dPartition *dp){
	myPrintk(0x5,"dPartition(start=0x%x, size=0x%x, firstFreeStart=0x%x)\n", dp, dp->size,dp->firstFreeStart);
}

// EMB 是每一个block的数据结构，userdata可以暂时不用管。
typedef struct EMB{
	unsigned long size;
	union {
		unsigned long nextStart;    // if free: pointer to next block
        unsigned long userData;		// if allocated, belongs to user
	};	                           
} EMB;	//共占8个字节

#define EMB_size ((unsigned long)0x8)

void showEMB(struct EMB * emb){
	myPrintk(0x3,"EMB(start=0x%x, size=0x%x, nextStart=0x%x)\n", emb, emb->size, emb->nextStart);
}

unsigned long align8(unsigned long n){
	if (n & 1) n += 1; // 消除最低位
	if (n & 2) n += 2; // 消除次低位
	if (n & 4) n += 4; // 消除次低位
	return n;
}	

unsigned long dPartitionInit(unsigned long start, unsigned long totalSize){
	// TODO
	/*功能：初始化内存。
	1. 在地址start处，首先是要有dPartition结构体表示整个数据结构(也即句柄)。
	2. 然后，一整块的EMB被分配（以后使用内存会逐渐拆分），在内存中紧紧跟在dP后面，然后dP的firstFreeStart指向EMB。
	3. 返回start首地址(也即句柄)。
	注意有两个地方的大小问题：
		第一个是由于内存肯定要有一个EMB和一个dPartition，totalSize肯定要比这两个加起来大。
		第二个注意EMB的size属性不是totalsize，因为dPartition和EMB自身都需要要占空间。
	
	*/
	if (totalSize <= dPartition_size + EMB_size)
		return 0;

	dPartition *dp = (dPartition *)start;
	dp->size = totalSize;
	dp->firstFreeStart = start + dPartition_size;

	// 
	EMB *block = (EMB *)dp->firstFreeStart;
	block->size = totalSize - dPartition_size;
	block->nextStart = 0;

	return start;

}


void dPartitionWalkByAddr(unsigned long dp){
	// TODO
	/*功能：本函数遍历输出EMB 方便调试
	1. 先打印dP的信息，可调用上面的showdPartition。
	2. 然后按地址的大小遍历EMB，对于每一个EMB，可以调用上面的showEMB输出其信息

	*/
	dPartition *handler = (dPartition *)dp;
	showdPartition(handler);

	unsigned long addr = handler->firstFreeStart;
	EMB *block;
	while (addr){
		block = (EMB *)addr;
		showEMB(block);
		addr = block->nextStart;
	}
}


//=================firstfit, order: address, low-->high=====================
/**
 * return value: addr (without overhead, can directly used by user)
**/

unsigned long dPartitionAllocFirstFit(unsigned long dp, unsigned long size){
	// TODO
	/*功能：分配一个空间
	1. 使用firstfit的算法分配空间，
	2. 成功分配返回首地址，不成功返回0
	3. 从空闲内存块组成的链表中拿出一块供我们来分配空间(如果提供给分配空间的内存块空间大于size，我们还将把剩余部分放回链表中)，并维护相应的空闲链表以及句柄
	注意的地方：
		1.EMB类型的数据的存在本身就占用了一定的空间。

	*/
	if (size <= 0) 
		return 0;


	dPartition *handler = (dPartition *)dp;
	if (!handler->firstFreeStart) 
		return 0;

	unsigned long size_align = align8(size);
	unsigned long addr = handler->firstFreeStart;
	unsigned long pre_addr = 0;
	EMB *block;
	EMB *pre_block;

	while (addr){
		block = (EMB *)addr;
		pre_block = (EMB *)pre_addr;

		if (block->size >= size_align + sizeof(unsigned long) && 
			block->size <= size_align + sizeof(unsigned long) + EMB_size){
			if (pre_block == 0)
				handler->firstFreeStart = block->nextStart;
			else
				pre_block->nextStart = block->nextStart;
			return addr + sizeof(unsigned long);
		}
		else if (block->size > size_align + sizeof(unsigned long) + EMB_size){
			unsigned long new_addr_node = addr + sizeof(unsigned long) + size_align;
			EMB *new_block = (EMB *)(new_addr_node);
			new_block->size = block->size - size_align - sizeof(unsigned long);
			new_block->nextStart = block->nextStart;
			block->size -= new_block->size;

			if (pre_block == 0)
				handler->firstFreeStart = new_addr_node;
			else
				pre_block->nextStart = new_addr_node;

			return addr + sizeof(unsigned long);
		}
	
		pre_addr = addr;
		addr = block->nextStart;
	}

	return 0; // no suitable block

}

// 
unsigned long dPartitionFreeFirstFit(unsigned long dp, unsigned long start){
	// TODO
	/*功能：释放一个空间
	1. 按照对应的fit的算法释放空间
	2. 注意检查要释放的start~end这个范围是否在dp有效分配范围内
		返回1 没问题
		返回0 error
	3. 需要考虑两个空闲且相邻的内存块的合并
	
	*/

	start -= sizeof(unsigned long);

	if (start < dp + dPartition_size) 
		return 0;

	dPartition *handler = (dPartition *)dp;

	if (start >= dp + handler->size)
		return 0;
	
	unsigned long addr = handler->firstFreeStart;
	unsigned long pre_addr = 0;
	unsigned long next_addr = 0;
	EMB *block;

	while (addr){
		block = (EMB *)addr;
		if (addr < start)
			pre_addr = addr;
		else if (addr > start){
			next_addr = addr;
			break;
		}
		addr = block->nextStart;
	}

	// free
	block = (EMB *)start;
	if (next_addr) {
		if (next_addr == start + block->size){
			EMB *next_block = (EMB *)next_addr;
			block->size += next_block->size;
			block->nextStart = next_block->nextStart;
		}
		else
			block->nextStart = next_addr;
	}
	else
		block->nextStart = 0;

	if (pre_addr){
		EMB *pre_block = (EMB *)pre_addr;
		if (start == pre_addr + pre_block->size){
			pre_block->size += block->size;
			pre_block->nextStart = block->nextStart;
		}
		else
			pre_block->nextStart = start;
	}
	else
		handler->firstFreeStart = start;

	return 1;
}


// 进行封装，此处默认firstfit分配算法，当然也可以使用其他fit，不限制。
unsigned long dPartitionAlloc(unsigned long dp, unsigned long size){
	return dPartitionAllocFirstFit(dp,size);
}

unsigned long dPartitionFree(unsigned long	 dp, unsigned long start){
	return dPartitionFreeFirstFit(dp,start);
}
