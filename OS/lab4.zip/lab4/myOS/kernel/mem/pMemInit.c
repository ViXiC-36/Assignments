#include "../../include/myPrintk.h"
#include "../../include/mem.h"
unsigned long pMemStart;  // 可用的内存的起始地址
unsigned long pMemSize;  // 可用的大小
unsigned long pMemHandler;  // 内存管理的句柄

void memTest(unsigned long start, unsigned long grainSize){
	// TODO
	/*功能：检测算法
		这一个函数对应实验讲解ppt中的第一大功能-内存检测。
		本函数的功能是检测从start开始有多大的内存可用，具体算法参照ppt检测算法的文字描述
	注意点三个：
	1、覆盖写入和读出就是往指针指向的位置写和读，不要想复杂。
	  (至于为什么这种检测内存的方法可行大家要自己想一下)
	2、开始的地址要大于1M，需要做一个if判断。
	3、grainsize不能太小，也要做一个if判断
	*/
    if (start < 0x100000) 
		start = 0x100000;
	if (grainSize < 2)
		grainSize = 2;

	unsigned long addr = start;
	unsigned short data;
	unsigned short *addr_first_2_bits;
	unsigned short *addr_last__2_bits;
	unsigned short test_data1 = 0xAA55;
	unsigned short test_data2 = 0x55AA;
	int fail = 0;
	pMemStart = start;
	pMemSize = 0;

	while (!fail){
		fail = 0;

		addr_first_2_bits = (unsigned short *)addr;
		addr_last__2_bits = (unsigned short *)(addr + grainSize - 2);

		// to first 2 bits
		data = *addr_first_2_bits; // read & cache
		*addr_first_2_bits = test_data1; // write 0xAA55
		if (*addr_first_2_bits != test_data1) 
			fail = 1; // write success ?
		*addr_first_2_bits = test_data2; // write 0x55AA
		if (*addr_first_2_bits != test_data2) 
			fail = 1; // write success ?
		*addr_first_2_bits = data; // write back

		// to last 2 bits
		data = *addr_last__2_bits; // read & cache
		*addr_last__2_bits = test_data1; // write 0xAA55
		if (*addr_last__2_bits != test_data1) 
			fail = 1; // write success ?
		*addr_last__2_bits = test_data2; // write 0x55AA
		if (*addr_last__2_bits != test_data2) 
			fail = 1; // write success ?
		*addr_last__2_bits = data; // write back

		if (!fail) {
			addr += grainSize;
			pMemSize += grainSize;
		}
	}

	myPrintk(0x7,"MemStart: %x  \n", pMemStart);
	myPrintk(0x7,"MemSize:  %x  \n", pMemSize);
	
}

extern unsigned long _end;
void pMemInit(void){
	unsigned long _end_addr = (unsigned long) &_end;
	memTest(0x100000,0x1000);
	myPrintk(0x7,"_end:  %x  \n", _end_addr);
	if (pMemStart <= _end_addr) {
		pMemSize -= _end_addr - pMemStart;
		pMemStart = _end_addr;
	}
	
	// 此处选择不同的内存管理算法
	pMemHandler = dPartitionInit(pMemStart,pMemSize);	
}
