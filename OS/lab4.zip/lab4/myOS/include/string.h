#ifndef __STRING_H__
#define __STRING_H__

int strcmp(unsigned char *str1, unsigned char *str2);
int strncpy(unsigned char *src, unsigned char *dest, unsigned int n);

#endif