#ifndef __FCFSTESTCASE_H__
#define __FCFSTESTCASE_H__

#include "../myOS/include/taskArrv.h"
#include "../myOS/include/task.h"
void FCFS_TEST(void);
#define WHITE 0x7

#endif