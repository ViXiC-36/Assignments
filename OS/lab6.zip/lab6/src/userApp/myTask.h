#ifndef _MYTASK_H
#define _MYTASK_H
void myTask0();
void myTask1();
void myTask2();
void myTask3();

#endif
