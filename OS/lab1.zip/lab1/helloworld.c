#include <stdio.h>

int main (void)
{
    //test
    printf("Hello World!\n");
    return 0;
}