# Lab 8 Report 方向2

--**PB22111599 杨映川**

## Part 1 串口协议

### 2-1 串口回显

代码：

>       module Uart_test (
>           input                   [ 0 : 0]            uart_din,
>           output                  [ 0 : 0]            uart_dout
>       );
>       assign uart_dout = uart_din;
>       endmodule

FPGA上板效果：
![Alt text](image.png)

### 2-2 串口发送模块

代码：

>       module Send(
>           input                   [ 0 : 0]        clk, 
>           input                   [ 0 : 0]        rst,
>       
>           output      reg         [ 0 : 0]        dout,
>       
>           input                   [ 0 : 0]        dout_vld,
>           input                   [ 7 : 0]        dout_data
>       );
>       
>       // Counter and parameters
>       localparam FullT        = 867;
>       localparam TOTAL_BITS   = 9;
>       reg [ 9 : 0] div_cnt;           // 分频计数器，范围 0 ~ 867
>       reg [ 4 : 0] dout_cnt;          // 位计数器，范围 0 ~ 9
>       
>       wire pos_edge;
>       Edge_capture  Edge_capture_inst (
>           .clk(clk),
>           .rst(rst),
>           .sig_in(dout_vld),
>       
>           .pos_edge(pos_edge),
>           .neg_edge()
>         );
>       
>       // Main FSM
>       localparam WAIT     = 0;
>       localparam SEND     = 1;
>       reg current_state, next_state;
>       always @(posedge clk) begin
>           if (rst)
>               current_state <= WAIT;
>           else
>               current_state <= next_state;
>       end
>       
>       always @(*) begin
>           next_state = current_state;
>           case (current_state)
>               // TODO
>               WAIT: begin
>                   if (pos_edge)
>                       next_state = SEND;
>                   else
>                       next_state = WAIT;
>               end
>               SEND: begin
>                   if (dout_cnt == TOTAL_BITS)
>                       next_state = WAIT;
>                   else
>                       next_state = SEND;
>               end
>               default:;
>           endcase
>       end
>       
>       // Counter
>       always @(posedge clk) begin
>           if (rst)
>               div_cnt <= 10'H0;
>           else if (current_state == SEND) begin
>               // TODO
>               if (div_cnt == FullT)
>                   div_cnt <= 10'h0; // reaching 867
>               else
>                   div_cnt <= div_cnt + 1'b1;
>           end
>           else
>               div_cnt <= 10'H0;
>       end
>       
>       always @(posedge clk) begin
>           if (rst)
>               dout_cnt <= 5'H0;
>           else if (current_state == SEND) begin
>               // TODO
>               if (dout_cnt == TOTAL_BITS)
>                   dout_cnt <= 5'h0;
>               else begin
>                   if (div_cnt == FullT)
>                       dout_cnt <= dout_cnt + 1;
>                   else
>                       dout_cnt <= dout_cnt;
>               end
>           end
>           else
>               dout_cnt <= 5'H0;
>       end
>       
>       reg [7 : 0] temp_data;      // 用于保留待发送数据，这样就不怕 dout_data 的变化了
>       always @(posedge clk) begin
>           if (rst)
>               temp_data <= 8'H0;
>           else if (current_state == WAIT && pos_edge) // 进入数字有效
>               temp_data <= dout_data;
>           else
>               temp_data <= temp_data;
>       end
>       
>       always @(posedge clk) begin
>           if (rst)
>               dout <= 1'B1;
>           else begin
>               // TODO
>               if (current_state == SEND)
>                   case (dout_cnt)
>                       5'd0: begin
>                           dout <= 0; // 
>                       end
>                       5'd1: begin
>                           dout <= temp_data[0];
>                       end
>                       5'd2: begin
>                           dout <= temp_data[1];
>                       end
>                       5'd3: begin
>                           dout <= temp_data[2];
>                       end
>                       5'd4: begin
>                           dout <= temp_data[3];
>                       end
>                       5'd5: begin
>                           dout <= temp_data[4];
>                       end
>                       5'd6: begin
>                           dout <= temp_data[5];
>                       end
>                       5'd7: begin
>                           dout <= temp_data[6];
>                       end
>                       5'd8: begin
>                           dout <= temp_data[7];
>                       end
>                       default: begin
>                           dout <= 1'b1;
>                       end
>                   endcase
>           end
>       end
>       endmodule

套用Top模块上板后效果：
使用switch控制输入16进制数68，并将其显示在hexplay上。按下button后对应ASCII码的字符‘h’显示在串口上
![Alt text](image-1.png)

### 2-3 串口接收模块

代码：

>       module Receive(
>           input                   [ 0 : 0]        clk,
>           input                   [ 0 : 0]        rst,
>       
>           input                   [ 0 : 0]        din,
>       
>           output      reg         [ 0 : 0]        din_vld,
>           output      reg         [ 7 : 0]        din_data
>       );
>       
>       // Counter and parameters
>       localparam FullT        = 867;
>       localparam HalfT        = 433;
>       localparam TOTAL_BITS   = 8;
>       reg [ 9 : 0] div_cnt;       // 分频计数器，范围 0 ~ 867
>       reg [ 3 : 0] din_cnt;       // 位计数器，范围 0 ~ 8
>       
>       // Main FSM
>       localparam WAIT     = 0;
>       localparam RECEIVE  = 1;
>       reg current_state, next_state;
>       always @(posedge clk) begin
>           if (rst)
>               current_state <= WAIT;
>           else
>               current_state <= next_state;
>       end
>       
>       always @(*) begin
>           next_state = current_state;
>           case (current_state)
>               // TODO
>               WAIT: begin
>                   if ((din == 0) && (div_cnt >= HalfT))
>                       next_state = RECEIVE;
>                   else
>                       next_state = WAIT;
>               end
>               RECEIVE: begin
>                   if ((din_cnt >= 8) && (div_cnt >= FullT))
>                       next_state = WAIT;
>                   else
>                       next_state = RECEIVE;
>               end
>           endcase
>       end
>       
>       // Counter
>       always @(posedge clk) begin
>           if (rst)
>               div_cnt <= 10'D0;
>           else if (current_state == WAIT) begin // STATE WAIT
>               // TODO
>               if(din == 0) begin
>                   if (div_cnt >= HalfT)
>                       div_cnt <= 0;
>                   else
>                       div_cnt <= div_cnt + 1'b1; 
>               end
>           end
>           else begin  // STATE RECEIVE
>               // TODO
>               if (div_cnt >= FullT)
>                   div_cnt <= 0;
>               else
>                   div_cnt <= div_cnt + 1;
>           end
>       end
>       
>       always @(posedge clk) begin
>           if (rst)
>               din_cnt <= 0;
>           else begin
>               // TODO
>               if ((current_state == RECEIVE) && (div_cnt == FullT)) 
>               begin
>                   if (din_cnt >= TOTAL_BITS)
>                       din_cnt <= 0;
>                   else
>                       din_cnt <= din_cnt + 1;
>               end
>               else
>                   din_cnt <= din_cnt;
>           end
>       end
>       
>       
>       // Output signals
>       reg [ 0 : 0] accept_din;    // 位采样信号
>       always @(*) begin
>           // accept_din = 1'B0;
>           // TODO
>           if ((div_cnt >= FullT) && (din_cnt < TOTAL_BITS))
>               accept_din = 1'b1;
>           else 
>               accept_din = 0;
>       end
>       
>       always @(*) begin
>           // din_vld = 1'B0;
>           // TODO
>           if ((div_cnt >= FullT) && (din_cnt >= TOTAL_BITS))
>               din_vld = 1'b1;
>           else
>               din_vld = 1'b0;
>       end
>       
>       always @(posedge clk) begin
>           if (rst)
>               din_data <= 8'B0;
>           else if (current_state == WAIT)
>               din_data <= 8'B0;
>           else if (accept_din)
>               din_data[din_cnt[2:0]] <= din;
>           else if (din_vld)
>               din_data <= din_data;
>       end
>       endmodule

上板效果：
在输入区输入Zeph，其对应ASCII值会依次显示在数码管上并进行左移更新
![Alt text](image-2.png)

## Part 2 应用 A 猜数字游戏

### 2-A-1 开关输入

代码：

>       module Input(
>           input                   [ 0 : 0]            clk,
>           input                   [ 0 : 0]            rst,
>           input                   [ 7 : 0]            sw,
>       
>           output      reg         [ 3 : 0]            hex,
>           output                  [ 0 : 0]            pulse
>       );
>       // 三级寄存器边沿检测
>       reg [7:0] sw_reg_1, sw_reg_2, sw_reg_3;
>       always @(posedge clk) begin
>           if (rst) begin
>               sw_reg_1 <= 0;
>               sw_reg_2 <= 0;
>               sw_reg_3 <= 0;
>           end
>           else begin
>               // TODO：补充边沿检测的代码
>               sw_reg_1 <= sw;
>               sw_reg_2 <= sw_reg_1;
>               sw_reg_3 <= sw_reg_2;
>           end
>       end
>       
>       wire [7:0] sw_change = sw_reg_2 ^ sw_reg_3;// TODO：检测上升沿
>       assign pulse = ((sw_reg_2[0] && ~sw_reg_3[0]) || 
>                       (sw_reg_2[1] && ~sw_reg_3[1]) ||
>                       (sw_reg_2[2] && ~sw_reg_3[2]) ||
>                       (sw_reg_2[3] && ~sw_reg_3[3]) ||
>                       (sw_reg_2[4] && ~sw_reg_3[4]) || 
>                       (sw_reg_2[5] && ~sw_reg_3[5]) ||
>                       (sw_reg_2[6] && ~sw_reg_3[6]) ||
>                       (sw_reg_2[7] && ~sw_reg_3[7])) ? 1 : 0;
>       always @(*) begin
>           case (sw_change)
>               8'h01: hex = 4'd0;
>               8'h02: hex = 4'd1;
>               8'h04: hex = 4'd2;
>               8'h08: hex = 4'd3;
>               8'h10: hex = 4'd4;
>               8'h20: hex = 4'd5;
>               8'h40: hex = 4'd6;
>               8'h80: hex = 4'd7;
>               default: hex = 4'd0;
>           endcase
>       end
>       
>       // TODO：编写代码，产生 hex 和 pulse 信号。
>       // Hint：这两个信号均为组合逻辑产生。
>       
>       endmodule

### 2-A-2 结果比对

代码：

>       module Check(
>           input                   [ 0 : 0]            clk,
>           input                   [ 0 : 0]            rst,
>       
>           input                   [11 : 0]            input_number,
>           input                   [11 : 0]            target_number,
>           input                   [ 0 : 0]            start_check,
>       
>           output     reg          [ 5 : 0]            check_result
>       );
>       // 模块内部用寄存器暂存输入信号，从而避免外部信号突变带来的影响
>       reg [11:0] current_input_data, current_target_data;
>       always @(posedge clk) begin
>           if (rst) begin
>               current_input_data <= 0;
>               current_target_data <= 0;
>           end
>           else if (start_check) begin 
>               current_input_data <= input_number;
>               current_target_data <= target_number;
>           end
>       end
>       
>       // 使用组合逻辑产生比较结果
>       wire [3:0] target_number_3, target_number_2, target_number_1;
>       wire [3:0] input_number_3, input_number_2, input_number_1;
>       assign input_number_1 = current_input_data[3:0];
>       assign input_number_2 = current_input_data[7:4];
>       assign input_number_3 = current_input_data[11:8];
>       assign target_number_1 = current_target_data[3:0];
>       assign target_number_2 = current_target_data[7:4];
>       assign target_number_3 = current_target_data[11:8];
>       
>       reg i1t1, i1t2, i1t3, i2t1, i2t2, i2t3, i3t1, i3t2, i3t3;
>       always @(*) begin
>           i1t1 = (input_number_1 == target_number_1);
>           i1t2 = (input_number_1 == target_number_2);
>           i1t3 = (input_number_1 == target_number_3);
>           i2t1 = (input_number_2 == target_number_1);
>           i2t2 = (input_number_2 == target_number_2);
>           i2t3 = (input_number_2 == target_number_3);
>           i3t1 = (input_number_3 == target_number_1);
>           i3t2 = (input_number_3 == target_number_2);
>           i3t3 = (input_number_3 == target_number_3);
>       end
>       
>       // TODO：按照游戏规则，补充 check_result 信号的产生逻辑
>       wire [1:0] BonnePlace;
>       wire [1:0] MalePlace;
>       assign BonnePlace = i1t1 + i2t2 + i3t3;
>       assign MalePlace  = ((i1t1) ? 0 : (i1t2 + i1t3)) +
>                           ((i2t2) ? 0 : (i2t1 + i2t3)) +
>                           ((i3t3) ? 0 : (i3t1 + i3t2));
>       always @(*) begin
>           case (BonnePlace)
>               2'b00: check_result[5:3] = 3'b000;
>               2'b01: check_result[5:3] = 3'b001;
>               2'b10: check_result[5:3] = 3'b010;
>               2'b11: check_result[5:3] = 3'b100;
>               default: ;
>           endcase
>       end
>       always @(*) begin
>           case (MalePlace)
>               2'b00: check_result[2:0] = 3'b000;
>               2'b01: check_result[2:0] = 3'b001;
>               2'b10: check_result[2:0] = 3'b010;
>               2'b11: check_result[2:0] = 3'b100;
>               default: ;
>           endcase
>       end
>       endmodule

### 2-A-3 计时器

代码：

>       module Timer(
>           input                   [ 0 : 0]            clk,
>           input                   [ 0 : 0]            rst,
>       
>           input                   [ 0 : 0]            set, // from Control
>           input                   [ 0 : 0]            en,  // from Control
>       
>           output                  [ 7 : 0]            minute,
>           output                  [ 7 : 0]            second,
>           output                  [11 : 0]            micro_second,
>       
>           output                  [ 0 : 0]            finish
>       );
>       
>       reg current_state, next_state;
>       localparam ON = 1;
>       localparam OFF = 0;
>       // Pt 1 state update
>       always @(posedge clk) begin
>           if (rst)
>               current_state <= OFF;
>           else
>               current_state <= next_state;
>       end
>       // TODO: Finish the FSM
>       //Pt 2 Logic Jump
>       always @(*) begin
>           next_state = current_state;
>           case (current_state)
>               ON: begin
>                   if (~en || finish) //
>                       next_state = OFF;
>                   else
>                       next_state = ON;
>               end
>               OFF: begin
>                   if (en)
>                       next_state = ON;
>                   else
>                       next_state = OFF;
>               end
>               default: begin
>                   next_state = current_state;
>               end
>           endcase
>       end
>       
>       localparam TIME_1MS = 100_000_000 / 1000;
>       reg [31 : 0] counter_1ms;
>       // TODO: Finish the counter
>       always @(posedge clk) begin
>           if (rst)
>               counter_1ms <= 0;
>           else if (current_state == ON)
>               if (counter_1ms >= TIME_1MS)
>                   counter_1ms <= 0;
>               else
>                   counter_1ms <= counter_1ms + 1;
>           else
>               counter_1ms <= 0;
>       end
>       
>       wire carry_in[2:0];
>       Clock # (
>           .WIDTH                  (8)    ,
>           .MIN_VALUE              (0)    ,
>           .MAX_VALUE              (59)   ,
>           .SET_VALUE              (1)      
>       ) minute_clock (
>           .clk                    (clk),
>           .rst                    (rst),
>           .set                    (set),
>           .carry_in               (carry_in[2]),
>           .carry_out              (finish),
>           .value                  (minute)
>       );
>       Clock # (
>           .WIDTH                  (8)   ,
>           .MIN_VALUE              (0)   ,
>           .MAX_VALUE              (59)  ,
>           .SET_VALUE              (0)      
>       ) second_clock (
>           .clk                    (clk),
>           .rst                    (rst),
>           .set                    (set),
>           .carry_in               (carry_in[1]),
>           .carry_out              (carry_in[2]),
>           .value                  (second)
>       );
>       Clock # (
>           .WIDTH                  (12)   ,
>           .MIN_VALUE              (0)    ,
>           .MAX_VALUE              (999)  ,
>           .SET_VALUE              (0)      
>       ) micro_second_clock (
>           .clk                    (clk),
>           .rst                    (rst),
>           .set                    (set),
>           .carry_in               (carry_in[0]),
>           .carry_out              (carry_in[1]),
>           .value                  (micro_second)
>       );
>       // TODO: what's carry_in[0] ?
>       assign carry_in[0] = (counter_1ms == TIME_1MS);
>       
>       
>       endmodule

### 2-A-4 控制单元

结合讲义中给出的模块关系图进行拼装
代码：

>       module Control ( // FSM ????
>           input                   [ 0 : 0]            clk,
>           input                   [ 0 : 0]            rst,
>           input                   [ 0 : 0]            btn,
>       
>           input                   [ 5 : 0]            check_result,
>       
>           output      reg         [ 0 : 0]            check_start,
>           output      reg         [ 0 : 0]            timer_en,
>           output      reg         [ 0 : 0]            timer_set,
>       
>           input                   [ 0 : 0]            timer_finish,
>       
>           output      reg         [ 1 : 0]            led_sel,
>           output      reg         [ 1 : 0]            seg_sel
>       );
>       
>       
>       reg [1:0] current_state, next_state;
>       // Pt 1, state update
>       localparam FLOW = 2'b00;
>       localparam CALC = 2'b01;
>       localparam WINN = 2'b10;
>       localparam LOSE = 2'b11;
>       
>       always @(posedge clk) begin
>           if (rst)
>               current_state <= FLOW;
>           else
>               current_state <= next_state;
>       end
>       //Pt 2, Logic Jump
>       always @(*) begin
>           next_state = current_state;
>           case (current_state)
>               FLOW: begin
>                   if (check_start)
>                       next_state = CALC;
>                   else
>                       next_state = FLOW;
>               end
>               CALC: begin
>                   if (timer_finish)
>                       next_state = LOSE;
>                   else if (check_result == 6'b100_000)
>                       next_state = WINN;
>                   else
>                       next_state = CALC;
>               end
>               WINN: begin
>               end
>               LOSE: begin
>               end
>               default: begin
>                   next_state = current_state;
>               end
>           endcase
>       end
>       // Pt 3, Outputs
>       always @(posedge clk) begin
>           if (rst)
>               timer_en <= 1;
>           else if ((current_state == WINN) || (current_state == LOSE))
>               timer_en <= 0;
>           else
>               timer_en <= 1;
>       end
>       always @(posedge clk) begin
>           if (rst)
>               timer_set <= 1;
>           else if ((current_state == WINN) || (current_state == LOSE))
>               timer_set <= 1;
>           else
>               timer_set <= 0;
>       end
>       always @(*) begin
>           check_start = btn;
>       end
>       
>       always @(posedge clk) begin
>           case (current_state)
>               FLOW: begin
>                   led_sel <= FLOW;
>                   seg_sel <= CALC;
>               end
>               CALC: begin
>                   led_sel <= CALC;
>                   seg_sel <= CALC;
>               end
>               WINN: begin
>                   seg_sel <= WINN;
>               end
>               LOSE: begin
>                   seg_sel <= LOSE;
>               end
>               default: ;
>           endcase
>       end
>       endmodule

### 2-A-5 拼装

调整各输入输出的接口位置
代码：

>       module Basic (
>           input                   [ 0 : 0]            clk,
>           input                   [ 0 : 0]            btn,
>           input                   [ 7 : 0]            sw,
>       
>           output                  [ 7 : 0]            led,
>           output                  [ 2 : 0]            seg_an,
>           output                  [ 3 : 0]            seg_data
>       );
>       
>       wire rst = sw[7];
>       
>       wire [0:0] pos_edge;
>       Edge_capture  Edge_capture_inst (
>           .clk(clk),
>           .rst(rst),
>           .sig_in(btn),
>           .pos_edge(pos_edge),
>           .neg_edge()
>         );
>       
>         wire [7:0] minute;
>         wire [7:0] second;
>         wire [11:0] micro_second;
>         wire [0:0] timer_set;
>         wire [0:0] timer_en; 
>         wire [0:0] timer_finish;
>           Timer  Timer_inst (
>           .clk(clk),
>           .rst(rst),
>           .set(timer_set),
>           .en(timer_en),
>       
>           .minute(minute),
>           .second(second),
>           .micro_second(micro_second),
>           .finish(timer_finish)
>         );
>       
>         wire [5:0] check_result;
>         wire [0:0] check_start;
>         wire [11:0] input_data;
>         Check  Check_inst (
>           .clk(clk),
>           .rst(rst),
>           .input_number(input_data),
>           .target_number(12'h520),
>           .start_check(check_start),
>       
>           .check_result(check_result)
>         );
>       
>         wire [1:0] led_sel;
>         wire [1:0] seg_sel;
>         Control  Control_inst (
>           .clk(clk),
>           .rst(rst),
>           .btn(pos_edge),
>           .check_result(check_result), // input
>           
>           .check_start(check_start),
>           .timer_en(timer_en),
>           .timer_set(timer_set), // output
>           
>           .timer_finish(timer_finish), // input
>       
>           .led_sel(led_sel),
>           .seg_sel(seg_sel)
>         );
>       
>         
>       
>       wire [0:0] pulse;
>       wire [3:0] hex;
>       
>         ShiftReg  ShiftReg_inst (
>           .clk(clk),
>           .rst(rst),
>           .hex(hex),
>           .pulse(pulse),
>           .dout(input_data)
>         );
>       
>         Input  Input_inst (
>           .clk(clk),
>           .rst(rst),
>           .sw(sw),
>           .hex(hex),
>           .pulse(pulse)
>         );
>       
>         wire [7:0] flow_led;
>         LED_flow  LED_flow_inst (
>           .clk(clk),
>           .btn(rst),
>           .led(flow_led)
>         );
>       
>       
>         MUX4 # (
>           .WIDTH(8)
>         )
>         MUX4_led (
>           .src0(flow_led),
>           .src1({{2{1'b0}}, check_result}),
>           .src2(),
>           .src3(),
>           .sel(led_sel),
>           .res(led)
>         );
>       
>         wire [31:0] seg_res;
>         MUX4 # (
>           .WIDTH(32)
>         )
>         MUX4_seg (
>           .src0(32'h0000_0000),
>           .src1({minute, second, {4{1'b0}}, micro_second}),
>           .src2(32'h8888_8888),
>           .src3(32'h4444_4444),
>           .sel(seg_sel),
>           .res(seg_res)
>         );
>       
>         Segment  Segment_inst (
>           .clk(clk),
>           .rst(rst),
>           .output_data(seg_res),
>       
>           .seg_data(seg_data),
>           .seg_an(seg_an)
>         );
>       endmodule

上板效果：
进入游戏后立刻开始倒计时：

![Alt text](image-3.png)

提前设置好答案为520.
此时输入205，led2亮起，表示3个数字均正确但都不在正确位置上

![Alt text](image-4.png)

再输入521，led4亮起，表示有两个数字正确且在正确位置上

![Alt text](image-6.png)

倒计时结束但仍然未猜出答案，游戏失败，数码管显示一整排4

![Alt text](image-5.png)

若在倒计时结束前输入正确答案，游戏成功，数码管显示一整排8

![Alt text](image-7.png)

### 2-A-6 更高级的猜数字游戏

#### 倒计时闪烁

增加了SegmentMask模块，实现对倒计时闪烁的控制
代码：

>       module SegmentMask # (
>           parameter ONE_SEC = 32'd100_000_000,
>           parameter HALF_SEC = 32'd50_000_000,
>           parameter QUAR_SEC = 32'd25_000_000
>       )
>       (
>           input       [0:0]        clk,
>           input       [0:0]        rst,
>           input       [7:0]        minute,
>           input       [7:0]        second,
>           input       [0:0]        finish,
>         
>           output reg  [7:0]        valid
>           );
>       
>       reg [31:0] count;
>       always @(posedge clk) begin
>           if (rst)
>               count <= 0;
>           else begin
>               if (second <= 8'd3) begin
>                   if (count >= HALF_SEC)
>                       count <= 0;
>                   else
>                       count <= count + 1;
>               end
>               else begin
>                   if (count >= ONE_SEC)
>                       count <= 0;
>                   else
>                       count <= count + 1;
>               end       
>           end
>       end
>       
>       always @(posedge clk) begin
>           if (rst)
>               valid <= 8'hff;
>           else if (minute == 8'h00) begin
>               if (second <= 8'd10) begin
>                   if (second <= 8'd3) begin
>                       if (count <= QUAR_SEC)
>                           valid <= 8'h00;
>                       else
>                           valid <= 8'hff;
>                   end
>                   else begin
>                       if (count <= HALF_SEC)
>                           valid <= 8'h00;
>                       else
>                           valid <= 8'hff;
>                   end
>               end
>               else
>                   valid <= 8'hff;
>           end
>           else
>               valid <= 8'hff;
>       end
>       endmodule

#### 随机生成题目

增加Random模块，并将时间，上次的输入和当前答案综合作为随机种子
代码：

>       module Random(
>           input                   [ 0 : 0]            clk,
>           input                   [ 0 : 0]            rst,
>           input                   [ 0 : 0]            generate_random,
>           input                   [ 7 : 0]            sw_seed,
>           input                   [ 7 : 0]            timer_seed,
>       
>           output                  [11 : 0]            random_data
>       );
>       reg [11:0] targets [0: 255];
>       always @(posedge clk) begin
>           // 这里用 initial 也可以，只要让 targets 中的数值保持不变即可。
>           targets[ 0] <= 12'h012;
>           targets[ 1] <= 12'h013;
>           targets[ 2] <= 12'h014;
>           targets[ 3] <= 12'h015;
>           targets[ 4] <= 12'h021;
>           targets[ 5] <= 12'h023;
>           targets[ 6] <= 12'h024;
>           targets[ 7] <= 12'h025;
>           targets[ 8] <= 12'h031;
>           targets[ 9] <= 12'h032;
>           targets[10] <= 12'h034;
>           targets[11] <= 12'h035;
>           targets[12] <= 12'h041;
>           targets[13] <= 12'h042;
>           targets[14] <= 12'h043;
>           targets[15] <= 12'h045;
>           targets[16] <= 12'h051;
>           targets[17] <= 12'h052;
>           targets[18] <= 12'h053;
>           targets[19] <= 12'h054;
>       
>           targets[20] <= 12'h102;
>           targets[21] <= 12'h103;
>           targets[22] <= 12'h104;
>           targets[23] <= 12'h105;
>           targets[24] <= 12'h120;
>           targets[25] <= 12'h123;
>           targets[26] <= 12'h124;
>           targets[27] <= 12'h125;
>           targets[28] <= 12'h130;
>           targets[29] <= 12'h132;
>           targets[30] <= 12'h134;
>           targets[31] <= 12'h135;
>           targets[32] <= 12'h140;
>           targets[33] <= 12'h142;
>           targets[34] <= 12'h143;
>           targets[35] <= 12'h145;
>           targets[36] <= 12'h150;
>           targets[37] <= 12'h152;
>           targets[38] <= 12'h153;
>           targets[39] <= 12'h154;
>       
>           targets[40] <= 12'h201;
>           targets[41] <= 12'h203;
>           targets[42] <= 12'h204;
>           targets[43] <= 12'h205;
>           targets[44] <= 12'h210;
>           targets[45] <= 12'h213;
>           targets[46] <= 12'h214;
>           targets[47] <= 12'h215;
>           targets[48] <= 12'h230;
>           targets[49] <= 12'h231;
>           targets[50] <= 12'h234;
>           targets[51] <= 12'h235;
>           targets[52] <= 12'h240;
>           targets[53] <= 12'h241;
>           targets[54] <= 12'h243;
>           targets[55] <= 12'h245;
>           targets[56] <= 12'h250;
>           targets[57] <= 12'h251;
>           targets[58] <= 12'h253;
>           targets[59] <= 12'h254;
>       
>           targets[60] <= 12'h301;
>           targets[61] <= 12'h302;
>           targets[62] <= 12'h304;
>           targets[63] <= 12'h305;
>           targets[64] <= 12'h310;
>           targets[65] <= 12'h312;
>           targets[66] <= 12'h314;
>           targets[67] <= 12'h315;
>           targets[68] <= 12'h320;
>           targets[69] <= 12'h321;
>           targets[70] <= 12'h324;
>           targets[71] <= 12'h325;
>           targets[72] <= 12'h340;
>           targets[73] <= 12'h341;
>           targets[74] <= 12'h342;
>           targets[75] <= 12'h345;
>           targets[76] <= 12'h350;
>           targets[77] <= 12'h351;
>           targets[78] <= 12'h352;
>           targets[79] <= 12'h354;
>       
>           targets[80] <= 12'h401;
>           targets[81] <= 12'h402;
>           targets[82] <= 12'h403;
>           targets[83] <= 12'h405;
>           targets[84] <= 12'h410;
>           targets[85] <= 12'h412;
>           targets[86] <= 12'h413;
>           targets[87] <= 12'h415;
>           targets[88] <= 12'h420;
>           targets[89] <= 12'h421;
>           targets[90] <= 12'h423;
>           targets[91] <= 12'h425;
>           targets[92] <= 12'h430;
>           targets[93] <= 12'h431;
>           targets[94] <= 12'h432;
>           targets[95] <= 12'h435;
>           targets[96] <= 12'h450;
>           targets[97] <= 12'h451;
>           targets[98] <= 12'h452;
>           targets[99] <= 12'h453;
>       
>           targets[100] <= 12'h501;
>           targets[101] <= 12'h502;
>           targets[102] <= 12'h503;
>           targets[103] <= 12'h504;
>           targets[104] <= 12'h510;
>           targets[105] <= 12'h512;
>           targets[106] <= 12'h513;
>           targets[107] <= 12'h514;
>           targets[108] <= 12'h520;
>           targets[109] <= 12'h521;
>           targets[110] <= 12'h523;
>           targets[111] <= 12'h524;
>           targets[112] <= 12'h530;
>           targets[113] <= 12'h531;
>           targets[114] <= 12'h532;
>           targets[115] <= 12'h534;
>           targets[116] <= 12'h540;
>           targets[117] <= 12'h541;
>           targets[118] <= 12'h542;
>           targets[119] <= 12'h543;
>       end
>       
>       reg [7 : 0] index;
>       always @(posedge clk) begin
>           if (rst)
>               index <= 0;
>           else if (generate_random) begin
>               if (index < 119)
>                   index <= index + 1;
>               else
>                   index <= 0;
>           end
>           else
>               index <= (index + sw_seed + timer_seed) % 120;
>       end
>       assign random_data = targets[index];
>       
>       // always @(posedge clk) begin
>       //     if (rst)
>       //         index <= 0;
>       //     else
>       //         index <= (index + sw_seed + timer_seed) % 120;
>       // end
>       
>       endmodule

#### BCD码显示

增加Hex2BCD模块，使用组合逻辑直接对十六进制数字进行转换
代码：

>       module Hex2BCD#( 
>           parameter                W = 32
>       )  // input width
>       ( 
>           input      [W-1      :0] bin   ,  // binary
>           output reg [W+(W-4)/3:0] bcd        //12 + (12-4)/3 = 14
>       ); // bcd {...,thousands,hundreds,tens,ones}
>       
>         integer i,j;
>       
>         always @(bin) begin
>           for(i = 0; i <= W+(W-4)/3; i = i+1) bcd[i] = 0;     // initialize with zeros
>           bcd[W-1:0] = bin;                                   // initialize with input vector
>           for(i = 0; i <= W-4; i = i+1)                       // iterate on structure depth
>             for(j = 0; j <= i/3; j = j+1)                     // iterate on structure width
>               if (bcd[W-i+4*j -: 4] > 4)                      // if > 4
>                 bcd[W-i+4*j -: 4] = bcd[W-i+4*j -: 4] + 4'd3; // add 3
>         end
>       
>       endmodule

#### 串口命令

对输入的信号进行信号转换，使用UartDecode模块
其中例化的模块为Part 1编写的模块
代码;

>       module UartDecode(
>           input                   [ 0 : 0]        clk,
>           input                   [ 0 : 0]        rst,
>           input                   [ 0 : 0]        uart_din,
>           output         reg                      uart_answer,
>           output         reg                      uart_pause,
>           output         reg                      uart_new
>       );
>       
>       wire [ 7 : 0]   din_data;
>       wire [ 0 : 0]   din_vld;
>       
>       Uart_Receive receive (
>           .clk        (clk),
>           .rst        (rst),
>           .din        (uart_din),
>           .din_vld    (din_vld),
>           .din_data   (din_data)
>       );
>       
>       localparam WAIT = 4'b0000;
>       localparam a1 = 4'b0001;
>       localparam a2 = 4'b0010;
>       localparam n1 = 4'b0011;
>       localparam n2 = 4'b0100;
>       localparam p1 = 4'b0101;
>       localparam p2 = 4'b0110;
>       localparam p3 = 4'b0111;
>       localparam p4 = 4'b1000;
>       
>       reg [3:0] current_state,next_state;
>       always @(posedge clk) begin
>           if(rst)
>               current_state <= WAIT;
>           else
>               current_state <= next_state;
>       end
>       
>       always @(*) begin
>           case (current_state)
>               WAIT:begin
>                   if(din_vld && din_data == "a")
>                       next_state = a1;
>                   else if(din_vld && din_data == "n")
>                       next_state = n1;
>                   else if(din_vld && din_data == "p")
>                       next_state = p1;
>                   else
>                       next_state = WAIT;
>               end 
>               a1:begin
>                   if(din_vld && din_data == ";")
>                       next_state = a2;
>                   else if(din_vld && din_data != ";")begin
>                       if(uart_pause)
>                           next_state = p2;
>                       else
>                           next_state = WAIT; 
>                   end 
>                   else
>                       next_state = a1;
>               end
>               a2:begin
>               if(uart_pause)
>                   next_state = p2;
>               else
>                   next_state = WAIT;
>               end
>               n1:begin
>                   if(din_vld && din_data == ";")
>                       next_state = n2;
>                   else if(din_vld && din_data != ";")
>                       next_state = WAIT;
>                   else
>                       next_state = n1;
>               end
>               n2:next_state = WAIT;
>               p1:begin
>                   if(din_vld && din_data == ";")
>                       next_state = p2;
>                   else if(din_vld && din_data != ";")
>                       next_state = WAIT;
>                   else
>                       next_state = p1;
>               end
>               p2:begin
>                   if(din_vld && din_data == "p")
>                       next_state = p3;
>                   else if(din_vld && din_data == "a")
>                       next_state = a1;
>                   else
>                       next_state = p2;
>               end
>               p3:begin
>                   if(din_vld && din_data == ";")
>                       next_state = p4;
>                   else if(din_vld && din_data != ";")
>                       next_state = p3;
>                   else
>                       next_state = p3;
>               end
>               p4:next_state = WAIT;
>               
>               default: next_state = WAIT;
>               endcase
>           end
>       
>       always @(posedge clk) begin
>           case (current_state)
>               WAIT:begin
>                   uart_answer <= 0;
>                   uart_pause <= 0;
>                   uart_new <= 0;
>               end
>               a1:begin
>                   uart_answer <= 0;
>                   uart_new <= 0;
>                   if(uart_pause)
>                       uart_pause <= 1;
>                   else 
>                       uart_pause <= 0;
>               end
>               a2:begin
>                   uart_answer <= 1;
>                   if(uart_pause)
>                       uart_pause <= 1;
>                   else 
>                       uart_pause <= 0;
>                   uart_new <= 0;
>               end
>               n1:begin
>                   uart_answer <= 0;
>                   uart_pause <= 0;
>                   uart_new <= 0;
>               end
>               n2:begin
>                   uart_answer <= 0;
>                   uart_pause <= 0;
>                   uart_new <= 1;
>               end
>               p1:begin
>                   uart_answer <= 0;
>                   uart_pause <= 0;
>                   uart_new <= 0;
>               end
>               p2:begin
>                   uart_answer <= 0;
>                   uart_pause <= 1;
>                   uart_new <= 0;
>               end
>               p3:begin
>                   uart_answer <= 0;
>                   uart_pause <= 1;
>                   uart_new <= 0;
>               end
>               p4:begin
>                   uart_answer <= 0;
>                   uart_pause <= 0;
>                   uart_new <= 0;
>               end
>           endcase
>       end
>       endmodule

对uart_answer信号进行反应并在串口输出上显示当前问题的答案
增加模块UartEncode
其中例化的模块为Part 1 中编写的模块
代码：

module UartEncode(
>           input                   [ 0 : 0]        clk,
>           input                   [ 0 : 0]        rst,
>           input                   [11 : 0]        target_number,
>           input                   [ 0 : 0]        print_en,
>       
>           output                  [ 0 : 0]        uart_dout
>       );
>       
>           localparam UOUT_WAIT        = 0;
>           localparam UOUT_PRINT       = 1;
>           localparam UOUT_TN          = 2;
>           reg [3 : 0] current_state, next_state;
>           always @(posedge clk) begin
>               if (rst)
>                   current_state <= UOUT_WAIT;
>               else
>                   current_state <= next_state;
>           end
>           reg [7:0] code_r1,code_r2,code_r3,code_r4,code_r5,code_r6,code_r7,code_r8,code_r9,code_r10,>    code_r11,code_r12,code_r13,code_r14,code_r15,code_r16,code_r17,code_r18,code_r19,code_r20;
    always @(*) begin
>               next_state = current_state;
>               case (current_state) 
>                   UOUT_WAIT: begin 
>                       if (print_en)
>                           next_state = UOUT_TN;
>                   end
>           
>                   UOUT_TN: next_state = UOUT_PRINT;
>           
>                   UOUT_PRINT: if (code_r1 == 0)
>                       next_state = UOUT_WAIT;      
>               endcase
>           end
>           
>           reg [19 : 0] div_cnt;
>           always @(posedge clk) begin
>               if (rst) 
>                   div_cnt <= 0;
>               else if (current_state == UOUT_PRINT) begin
>                   if (div_cnt < 20'D12000)
>                       div_cnt <= div_cnt + 1;  
>                   else
>                       div_cnt <= 0;
>               end             
>               else
>                   div_cnt <= 0;
>           end
>           
>           wire clk_100_pos = (div_cnt == 20'd11000);
>           
>       
>           localparam _N = 8'd10;
>           localparam _R = 8'd13; 
>           always @(posedge clk) begin
>               if (rst) begin
>                   code_r1 <= 0;
>                   code_r2 <= 0;
>                   code_r3 <= 0;
>                   code_r4 <= 0;
>                   code_r5 <= 0;
>                   code_r6 <= 0;
>                   code_r7 <= 0;
>                   code_r8 <= 0;
>                   code_r9 <= 0;
>                   code_r10 <= 0;
>                   code_r11 <= 0;
>                   code_r12 <= 0;
>                   code_r13 <= 0;
>                   code_r14 <= 0;
>                   code_r15 <= 0;
>                   code_r16 <= 0;
>                   code_r17 <= 0;
>                   code_r18 <= 0;
>                   code_r19 <= 0;
>                   code_r20 <= 0;
>               end
>               else case(current_state) 
>                   UOUT_TN: begin
>                       code_r1 <= "t";
>                       code_r2 <= "a";
>                       code_r3 <= "r";
>                       code_r4 <= "g";
>                       code_r5 <= "e";
>                       code_r6 <= "t";
>                       code_r7 <= "_";
>                       code_r8 <= "n";
>                       code_r9 <= "u";
>                       code_r10 <= "m";
>                       code_r11 <= "b";
>                       code_r12 <= "e";
>                       code_r13 <= "r";
>                       code_r14 <= ":";
>                       code_r15 <= target_number[11:8] + 48;
>                       code_r16 <= target_number[7:4] + 48;
>                       code_r17 <= target_number[3:0] + 48;
>                       code_r18 <= _N;
>                       code_r19 <= _R;
>                   end
>           
>                   UOUT_PRINT: if (clk_100_pos) begin
>                       code_r1 <= code_r2; 
>                       code_r2 <= code_r3;
>                       code_r3 <= code_r4;
>                       code_r4 <= code_r5;
>                       code_r5 <= code_r6;
>                       code_r6 <= code_r7;
>                       code_r7 <= code_r8;
>                       code_r8 <= code_r9;
>                       code_r9 <= code_r10;
>                       code_r10 <= code_r11;
>                       code_r11 <= code_r12;
>                       code_r12 <= code_r13;
>                       code_r13 <= code_r14;
>                       code_r14 <= code_r15;
>                       code_r15 <= code_r16;
>                       code_r16 <= code_r17;
>                       code_r17 <= code_r18;
>                       code_r18 <= code_r19;
>                       code_r19 <= code_r20;
>                       code_r20 <= 0;     
>                   end
>               endcase
>           end
>       
>       reg dout_vld;// Uart dout
>       wire [7:0] dout_data;
>       assign dout_data = code_r1;
>       
>       always @(*)
>       dout_vld = (div_cnt == 20'd100) && (current_state == UOUT_PRINT);
>       
>       Uart_Send send(
>           .clk(clk),
>           .rst(rst),
>           .dout(uart_dout),
>           .dout_vld(dout_vld),
>           .dout_data(dout_data)
>       );
>       
>       endmodule

在加入以上功能后需要对Control模块和Top模块做诸多更改并连接端口，此处不做赘述

上板效果：
此时已实现展示BCD码
![Alt text](image-9.png)
输入p；后倒计时暂停
![Alt text](image-8.png)
输入n;后倒计时重置且刷新答案
![Alt text](image-10.png)
输入a;后在串口输出处显示当前答案
![Alt text](image-11.png)