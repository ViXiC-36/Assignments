# Lab 7 乘法器

## PB22111599 杨映川

### T1 乘法器基础版

#### 实验目的

请根据实验文档中给出的移位乘法器设计方法，设计一个基础的参数化移位乘法器。部分信号约定如下：

> start 为开始运算信号，默认值为 0。当 start 由 0 变为 1 时需要初始化内部的被乘数、乘数和乘积寄存器，并从下下个时钟周期开始进行乘法计算（初始化需要一个周期）。
> finish 为运算完成信号，默认值为 0。当 finish 变为 1 时，表明此时乘法器的输出端口 res 为有效的乘积结果。为了保证稳定性，finish 信号需要持续至少一个时钟周期的高电平。
> rst 为复位信号，默认值为 0。当 rst 变为 1 时，乘法器内部的被乘数、乘数和乘积寄存器清零，且状态跳转到 IDLE。
> a 和 b 为被乘数和乘数，均为 WIDTH 位宽的变量。
> res 为最终的乘积，为 2*WIDTH 位宽的变量。

#### 实现代码

>       module MUL #(
>           parameter                               WIDTH = 32
>       ) (
>           input                   [ 0 : 0]            clk,
>           input                   [ 0 : 0]            rst,
>           input                   [ 0 : 0]            start,
>           input                   [WIDTH-1 : 0]       a,
>           input                   [WIDTH-1 : 0]       b,
>           output      reg         [2*WIDTH-1:0]       res,
>           output      reg         [ 0 : 0]            finish
>       );
>       reg [2*WIDTH-1 : 0]     multiplicand;       // 被乘数寄存器
>       reg [  WIDTH-1 : 0]     multiplier;         // 乘数寄存器
>       reg [2*WIDTH-1 : 0]     product;            // 乘积寄存器
>       
>       localparam IDLE = 2'b00;            // 空闲状态。这个周期寄存器保持原值不变。当 start 为 1 时跳转到 INIT。
>       localparam INIT = 2'b01;            // 初始化。下个周期跳转到 CALC
>       localparam CALC = 2'b10;            // 计算中。计算完成时跳转到 DONE
>       localparam DONE = 2'b11;            // 计算完成。下个周期跳转到 IDLE
>       reg [1:0] current_state, next_state;
>       
>       // wire [WIDTH-1:0] temp_multiplicand;
>       // wire [WIDTH-1:0] temp_multiplier;
>       // wire [WIDTH*2-1:0] temp_product;
>       // 请完成有限状态机以及乘法器模块的设计
>       //***********************************************************************
>       //***********************************************************************
>       // FSM
>       // Part 1: state update
>       always @(posedge clk) begin
>         if (rst) begin
>             current_state <= IDLE;
>         end
>         else begin
>             current_state <= next_state;
>         end
>       end
>       
>       reg [9:0] count; // 计数确定计算次数
>       always @(posedge clk) begin
>         if (rst) begin
>           count <= 0;
>         end
>         else if (current_state == CALC)
>           if (count == WIDTH)
>             count <= 0;
>           else begin
>             count <= count + 1;
>           end
>       end
>       // Part 2: 逻辑跳转
>       always @(*) begin
>         next_state = current_state;
>         case (current_state)
>             IDLE: begin
>                 if (start)
>                     next_state = INIT;
>                 else
>                     next_state = IDLE; 
>             end
>             INIT: begin
>                 next_state = CALC;
>             end
>             CALC: begin
>                 if (count < WIDTH)
>                   next_state = current_state;
>                 else
>                   next_state = DONE;
>             end
>             DONE: begin
>                 next_state = IDLE;
>             end
>             default: begin
>                 next_state = IDLE;
>             end
>         endcase
>       end
>       
>       
>       // Part 3: output // FSM i aniyeyo_k!!!
>       always @(posedge clk) begin
>           case (current_state)
>             INIT: begin // initialization 
>               multiplicand <= {{(WIDTH){1'b0}}, a};
>               multiplier <= b;
>               product <= {2*WIDTH{1'b0}};
>             end 
>             CALC: begin
>               multiplicand <= multiplicand << 1;
>               multiplier <= multiplier >> 1;
>               product <= product + (multiplicand & {64{multiplier[0]}});
>             end
>             default:;
>           endcase
>       end
>       
>       always @(*)
>           finish = (current_state == DONE);
>       
>       always @(*) begin
>           res = product;
>       end
>       //************************************************************
>       //************************************************************
>       
>       
>       endmodule

仿真结果：
`8000_0000 * 8000_0000 = 4000_0000_0000_0000`
![Alt text](image-3.png)

### T2 乘法器优化版

#### 实验目的

减少空间的使用

#### 实现代码

>       module MULx #(
>           parameter                               WIDTH = 4
>       ) (
>           input                   [ 0 : 0]        clk,
>           input                   [ 0 : 0]        rst,
>           input                   [ 0 : 0]        start,
>           input                   [WIDTH-1 : 0]   a,
>           input                   [WIDTH-1 : 0]   b,
>           output      reg         [2*WIDTH-1:0]   res
>           ,output      reg         [ 0 : 0]        finish // 数码管使用时注释掉！
>       );
>       reg [WIDTH-1 : 0]     mulcand;       // 被乘数寄存器
>       reg [2*WIDTH : 0]     prod__mulier;            // 乘积寄存器
>       reg                   overflow;                  // 溢出位
>       // Write your code here
>       localparam IDLE = 2'b00;
>       localparam INIT = 2'b01;
>       localparam CALC = 2'b10;
>       localparam DONE = 2'b11;
>       
>       reg [1:0] current_state, next_state;
>       // FSM
>       // Part 1 state update
>       always @(posedge clk) begin
>           if (rst) begin
>               current_state <= IDLE;
>           end
>           else begin
>               current_state <= next_state;
>           end
>       end
>       
>       reg [9:0] count; // 计数确定计算次数
>       always @(posedge clk) begin
>         if (rst) begin
>           count <= 0;
>         end
>         else if (current_state == CALC)
>           if (count == WIDTH)
>             count <= 0;
>           else begin
>             count <= count + 1;
>           end
>       end
>       // Part 2 Logic Jump
>       always @(*) begin
>           next_state = current_state;
>           case (current_state)
>               IDLE: begin
>                   if (start)
>                       next_state = INIT;
>                   else
>                       next_state = IDLE;
>               end
>               INIT: begin
>                   next_state = CALC;
>               end
>               CALC: begin
>                 if (count < WIDTH)
>                   next_state = current_state;
>                 else
>                   next_state = DONE;
>               end
>               DONE: begin
>                   next_state = IDLE;
>               end
>               default: begin
>                   next_state = IDLE;
>               end
>           endcase
>       end
>       
>       // Part 3: output //FSMdewanaida_j!
>       always @(posedge clk) begin
>           case (current_state)
>               INIT: begin
>                   mulcand <= b;
>                   prod__mulier <= {{(WIDTH + 1){1'b0}}, a};
>                   overflow = 0;
>               end 
>               CALC: begin
>                   prod__mulier <= 
>                   (prod__mulier >> 1) + 
>                   {{1'b0}, {(WIDTH){prod__mulier[0]}} & {mulcand}, {(WIDTH){1'b0}}};
>               end
>               default:;
>           endcase
>       end
>       
>       always @(*) begin
>           finish = (current_state == DONE);
>       end // 数码管使用时注释掉！！！
>       
>       always @(*) begin
>           res = prod__mulier[WIDTH*2-1:0];
>       end
>       
>       
>       // End of your code
>       endmodule

在FPGA上板后效果如下：
![Alt text](image.png)
`4'b0111 * 4'b1111 = 8'h69`
在按下button后数码管出现计算结果并保持显示。

### T3 性能比较

取时钟频率为400MHz，即时钟周期设置为2.50ns
<br/>
对于vivado自带的乘法符号的运算，得到以下时间性能报告：
![Alt text](image-4.png)
可见WNS = 0.746ns

<br/>
对于优化版的乘法器（T2中的乘法器MULx），得到以下时间性能报告：
![alt txxt](image-5.png)

**(markdown寄寄了www图片在附带的文件夹figs里面)**
可见WNS = 0.382ns
<br/>
可见优化后的乘法器性能要比自带的乘法运算好。

**优化方案**：使用华莱士树+2位Booth编码设计有符号乘法器，先使用2位Booth编码来缩减乘法中部分积的个数，然后借助华莱士数减少累加的次数，最后把最后一层得到的两个输出相加即可。

### T4 有符号乘法

在进行计算之前判断两数的正负并记录信息
代码如下：
>       module MUL_signed #(
>           parameter                               WIDTH = 32
>       ) (
>           input                   [ 0 : 0]        clk,
>           input                   [ 0 : 0]        rst,
>           input                   [ 0 : 0]        start,
>           input                   [WIDTH-1 : 0]   a,
>           input                   [WIDTH-1 : 0]   b,
>           output      reg         [2*WIDTH-1:0]   res
>          ,output      reg         [ 0 : 0]        finish // 数码管使用时注释掉！
>       );
>       reg [WIDTH-1 : 0]     mulcand;       // 被乘数寄存器
>       reg [2*WIDTH : 0]     prod__mulier;            // 乘积寄存器
>       
>       wire negprod;
>       assign negprod = a[WIDTH-1] ^ b[WIDTH-1];
>       
>       wire [WIDTH-1:0] a_abs;
>       wire [WIDTH-1:0] b_abs;
>       
>       assign a_abs = (a[WIDTH-1]) ? (~a + 1'b1) : a;
>       assign b_abs = (b[WIDTH-1]) ? (~b + 1'b1) : b;
>       
>       // Write your code here
>       localparam IDLE = 2'b00;
>       localparam INIT = 2'b01;
>       localparam CALC = 2'b10;
>       localparam DONE = 2'b11;
>       
>       reg [1:0] current_state, next_state;
>       // FSM
>       // Part 1 state update
>       always @(posedge clk) begin
>           if (rst) begin
>               current_state <= IDLE;
>           end
>           else begin
>               current_state <= next_state;
>           end
>       end
>       
>       reg [9:0] count; // 计数确定计算次数
>       always @(posedge clk) begin
>         if (rst) begin
>           count <= 0;
>         end
>         else if (current_state == CALC)
>           if (count == WIDTH)
>             count <= 0;
>           else begin
>             count <= count + 1;
>           end
>       end
>       // Part 2 Logic Jump
>       always @(*) begin
>           next_state = current_state;
>           case (current_state)
>               IDLE: begin
>                   if (start)
>                       next_state = INIT;
>                   else
>                       next_state = IDLE;
>               end
>               INIT: begin
>                   next_state = CALC;
>               end
>               CALC: begin
>                 if (count < WIDTH)
>                   next_state = current_state;
>                 else
>                   next_state = DONE;
>               end
>               DONE: begin
>                   next_state = IDLE;
>               end
>               default: begin
>                   next_state = IDLE;
>               end
>           endcase
>       end
>       
>       // Part 3: output //FSMdewanaida_j!
>       always @(posedge clk) begin
>           case (current_state)
>       
>               INIT: begin
>                   mulcand <= b_abs;
>                   prod__mulier <= {{(WIDTH + 1){1'b0}}, a_abs};
>               end 
>               CALC: begin
>                   prod__mulier <= 
>                   (prod__mulier >> 1) + 
>                   {{1'b0}, {(WIDTH){prod__mulier[0]}} & {mulcand}, {(WIDTH){1'b0}}};
>               end
>               default:;
>           endcase
>       end
>       
>       always @(*) begin
>           finish = (current_state == DONE);
>       end // 数码管使用时注释掉！！！
>       
>       always @(*) begin
>           res = (negprod) ? (~(prod__mulier[WIDTH*2-1:0]) + 1'b1) : prod__mulier[WIDTH*2-1:0];
>       end
>       
>       
>       // End of your code
>       endmodule

仿真波形如下：
![Alt text](image-1.png)
`-1 * 1 = -1`

### T*2 单周期树形乘法器

#### 实验目的:

通过加法器树来构造一个更高效的组合逻辑乘法器。

#### 实现代码：

>       module MUL_comb #(
>           parameter WIDTH = 8
>       )
>       (
>           input                   [ 7 : 0]        a,
>           input                   [ 7 : 0]        b,
>           output                  [15 : 0]        res
>       );
>       // Write your codes here.
>       
>       wire [7:0] and_res [7:0];
>       assign and_res[0] = a & {8{b[0]}};
>       assign and_res[1] = a & {8{b[1]}};
>       assign and_res[2] = a & {8{b[2]}};
>       assign and_res[3] = a & {8{b[3]}};
>       assign and_res[4] = a & {8{b[4]}};
>       assign and_res[5] = a & {8{b[5]}};
>       assign and_res[6] = a & {8{b[6]}};
>       assign and_res[7] = a & {8{b[7]}};
>       
>       wire [15:0] extded [7:0];
>       assign extded[0] = {{8{1'b0}}, and_res[0]} << 0;
>       assign extded[1] = {{8{1'b0}}, and_res[1]} << 1;
>       assign extded[2] = {{8{1'b0}}, and_res[2]} << 2;
>       assign extded[3] = {{8{1'b0}}, and_res[3]} << 3;
>       assign extded[4] = {{8{1'b0}}, and_res[4]} << 4;
>       assign extded[5] = {{8{1'b0}}, and_res[5]} << 5;
>       assign extded[6] = {{8{1'b0}}, and_res[6]} << 6;
>       assign extded[7] = {{8{1'b0}}, and_res[7]} << 7;
>       
>       //**********************************************
>       wire [15:0] s_1 [3:0];
>       Adder_16bit  Adder_16bit_inst (
>           .a(extded[0]),
>           .b(extded[1]),
>           .ci(0),
>           .s(s_1[0]),
>           .co()
>         );
>       
>         Adder_16bit  Adder_16bit_instt (
>           .a(extded[2]),
>           .b(extded[3]),
>           .ci(0),
>           .s(s_1[1]),
>           .co()
>         );
>       
>         Adder_16bit  Adder_16bit_insttt (
>           .a(extded[4]),
>           .b(extded[5]),
>           .ci(0),
>           .s(s_1[2]),
>           .co()
>         );
>       
>         Adder_16bit  Adder_16bit_instttt (
>           .a(extded[6]),
>           .b(extded[7]),
>           .ci(0),
>           .s(s_1[3]),
>           .co()
>         );
>       //******************************************
>         wire [15:0] s_2 [1:0];
>         Adder_16bit  Adder_16bit_insttttt (
>           .a(s_1[0]),
>           .b(s_1[1]),
>           .ci(0),
>           .s(s_2[0]),
>           .co()
>         );
>       
>         Adder_16bit  Adder_16bit_instttttt (
>           .a(s_1[2]),
>           .b(s_1[3]),
>           .ci(0),
>           .s(s_2[1]),
>           .co()
>         );
>       // ******************************************
>         Adder_16bit  Adder_16bit_insttttttt (
>           .a(s_2[0]),
>           .b(s_2[1]),
>           .ci(0),
>           .s(res),
>           .co()
>         );
>       
>       endmodule

画出相应的电路图为：
![Alt text](image-2.png)

#### 分析

经过了23个I/O ports，f = 1/ （通过23个ports的总时间）。