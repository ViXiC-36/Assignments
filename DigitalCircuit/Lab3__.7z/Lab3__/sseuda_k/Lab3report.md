# Lab 3 Report
## PB22111599 杨映川

#T1
代码：
>     module Top (
>         input   [7:0]                       sw,
>         output  [7:0]                       led
>     );
>     assign led = {sw[0], sw[1], sw[2], sw[3], sw[4], sw[5], sw[6], sw[7]};    
>     endmodule

在FPGA中实现的效果：
![switchforLED](image.png)
可见实现了开关sw逆序控制led
在上图中，有：
`sw[0]` for `led[7]`
`sw[3]` for `led[4]`
`sw[6]` for `led[1]`

---
#T2
代码：
>     module Counter #(
>         parameter   MID_VALUE = 27'd50_000_000,
>         parameter   MAX_VALUE = 27'd100_000_000
>     )(
>         input                   clk,
>         input                   btn,
>         output reg [7:0]        led
>     );
>     wire rst;
>     
>     assign rst = btn;   // Use button for RESET
>     
>     reg [26:0] counter;
>     always @(posedge clk) begin
>         if (rst)
>             counter <= 0;
>         else begin
>             if (counter >= MAX_VALUE)
>                 counter <= 0;
>             else
>                 counter <= counter + 27'b1;
>         end
>     end
>     
>     always @(posedge clk) begin
>         if (rst)
>             led <= 8'b0000_0000;
>         else if (counter >= MID_VALUE)
>             led <= 8'b0000_0000;
>         else
>             led <= 8'b1111_1111;
>     end
>     endmodule
使用`btn`控制重置，按下`btn`时，LED灯停止闪烁；
由于平台上的时钟频率为100MHz，故计数器在跟随上升沿变化每100M次就是1秒时间
当没有按下`btn`时，使用计数器进行计时，
以100MHz为周期（每计数达到100M就重置并开始下一次计数），
在时序电路中，当计数器大于50M（每0.5秒）时，令`led <= 8'b0000_0000`，LED灯不亮；
否则（计数器小于50M，每0.5秒）`led <= 8'b1111_1111`，LED灯亮起。

在FPGA中实现了以1秒为周期的闪烁效果:
![led twinkle](image-1.png)

---
##T3
使用计数器进行周期为400的计数过程，每次达到400时让`seg_id`自增1，因为`seg_id`是3位寄存器，多余的位数会被自动截断，故`seg_id`在0到7之间循环变化，从而实现计时切换当前被点亮的数码管编号。此部分的实现代码如下：
>     reg [31:0] counter;
>     always @(posedge clk) begin
>         if (rst)
>             counter <= 0;
>         else begin 
>             if (counter >= 32'd400)
>                 counter <= 0;
>             else
>                 counter <= counter + 1;
>         end
>     end
>     
>     reg [2:0] seg_id;
>     always @(posedge clk) begin
>         if (rst)
>             seg_id <= 0;
>         else begin
>             if (counter >= 32'd400)
>                 seg_id <= seg_id + 1;
>             else
>                 seg_id <= seg_id;
>         end
>     end
接下来用`seg_an`代表数码管的位数，并将`output_data`的内容显示出来。该部分的实现代码如下：
>     always @(*) begin
>         seg_data = 0;
>         seg_an = seg_id;    // <- Same for all cases
>     
>         // Update seg_data according to seg_id.
>         case (seg_an)
>             3'd0: seg_data = {output_data[3:0]};
>             3'd1: seg_data = {output_data[7:4]};
>             3'd2: seg_data = {output_data[11:8]};
>             3'd3: seg_data = {output_data[15:12]};
>             3'd4: seg_data = {output_data[19:16]};
>             3'd5: seg_data = {output_data[23:20]};
>             3'd6: seg_data = {output_data[27:24]};
>             3'd7: seg_data = {output_data[31:28]};
>             default: seg_data = 0;
>         endcase
>     end
在进行实现时另外使用名为TTop的module，并对以上的Segment模块进行例化。TTop的代码如下：
>     module TTop(
>         input                   clk,
>         input                   btn,
>         output [2:0]            seg_an,
>         output [3:0]            seg_data
>     );
>     Segment segment(
>         .clk(clk),
>         .rst(btn),
>         .output_data(32'h22111599),     // <- 学号中的 8 位数字
>         .seg_data(seg_data),
>         .seg_an(seg_an)
>     );
>     endmodule
在FPGA中实现效果如下：
![stunum](image-2.png)
>>>补充：Segment的全部代码：
>>>     module Segment(
>>>         input                       clk,
>>>         input                       rst,
>>>         input       [31:0]          output_data,
>>>     
>>>         output reg  [ 3:0]          seg_data,
>>>         output reg  [ 2:0]          seg_an
>>>     );
>>>     
>>>     reg [31:0] counter;
>>>     always @(posedge clk) begin
>>>         if (rst)
>>>             counter <= 0;
>>>         else begin 
>>>             if (counter >= 32'd400)
>>>                 counter <= 0;
>>>             else
>>>                 counter <= counter + 1;
>>>         end
>>>     end
>>>     
>>>     reg [2:0] seg_id;
>>>     always @(posedge clk) begin
>>>         if (rst)
>>>             seg_id <= 0;
>>>         else begin
>>>             if (counter >= 32'd400)
>>>                 seg_id <= seg_id + 1;
>>>             else
>>>                 seg_id <= seg_id;
>>>         end
>>>     end
>>>     
>>>     // wire [31:0] output_data;
>>>     always @(*) begin
>>>         seg_data = 0;
>>>         seg_an = seg_id;    // <- Same for all cases
>>>     
>>>         // Update seg_data according to seg_id.
>>>         case (seg_an)
>>>             3'd0: seg_data = {output_data[3:0]};
>>>             3'd1: seg_data = {output_data[7:4]};
>>>             3'd2: seg_data = {output_data[11:8]};
>>>             3'd3: seg_data = {output_data[15:12]};
>>>             3'd4: seg_data = {output_data[19:16]};
>>>             3'd5: seg_data = {output_data[23:20]};
>>>             3'd6: seg_data = {output_data[27:24]};
>>>             3'd7: seg_data = {output_data[31:28]};
>>>             default: seg_data = 0;
>>>         endcase
>>>     end    
>>>     endmodule
---
##T*3
要实现开关对数码管显示与否的控制，只需在T3的Segment模块中进行一处修改，即在对`seg_an`进行赋值时进行`output_valid`的真假判断：
>     seg_an = (output_valid[seg_id] == 1) ? seg_id : 0; 
再在例化了Segment模块的Top模块中，将开关`sw[7:0]`接入：
>     module Top(
>         input                   clk,
>         input                   btn,
>         input  [7:0]            sw,
>     
>         output [2:0]            seg_an,
>         output [3:0]            seg_data
>     );
>     
>     Segment segment(
>         .clk(clk),
>         .rst(btn),
>         .output_valid(sw),
>         .output_data(32'h22111599),     // <- 学号中的 8 位数字
>         .seg_data(seg_data),
>         .seg_an(seg_an)
>     );
>     
>     endmodule
在FPGA中实现效果如下：
![Ctrl stunum](image-3.png)
第0位数码管始终亮起，其他数码管必须在对应的开关打开后才会亮起。
>>>     补充：Segment模块的完整代码：
>>>     module Segment(
>>>         input                       clk,
>>>         input                       rst,
>>>         input       [31:0]          output_data,
>>>         input       [ 7:0]          output_valid,
>>>     
>>>         output reg  [ 3:0]          seg_data,
>>>         output reg  [ 2:0]          seg_an
>>>     );
>>>     
>>>     reg [31:0] counter;
>>>     always @(posedge clk) begin
>>>         if (rst)
>>>             counter <= 0;
>>>         else begin 
>>>             if (counter >= 32'd400)
>>>                 counter <= 0;
>>>             else
>>>                 counter <= counter + 1;
>>>         end
>>>     end
>>>     
>>>     reg [2:0] seg_id;
>>>     always @(posedge clk) begin
>>>         if (rst)
>>>             seg_id <= 0;
>>>         else begin
>>>             if (counter >= 32'd400)
>>>                 seg_id <= seg_id + 1;
>>>             else
>>>                 seg_id <= seg_id;
>>>         end
>>>     end
>>>     
>>>     // wire [31:0] output_data;
>>>     always @(*) begin
>>>         seg_data = 0;
>>>         seg_an = (output_valid[seg_id] == 1) ? seg_id : 0;    // <- Same for all cases
>>>         
>>>         case (seg_an)
>>>             3'd0: seg_data = {output_data[3:0]};
>>>             3'd1: seg_data = {output_data[7:4]};
>>>             3'd2: seg_data = {output_data[11:8]};
>>>             3'd3: seg_data = {output_data[15:12]};
>>>             3'd4: seg_data = {output_data[19:16]};
>>>             3'd5: seg_data = {output_data[23:20]};
>>>             3'd6: seg_data = {output_data[27:24]};
>>>             3'd7: seg_data = {output_data[31:28]};
>>>             default: seg_data = 0;
>>>         endcase
>>>     end
>>>     endmodule
