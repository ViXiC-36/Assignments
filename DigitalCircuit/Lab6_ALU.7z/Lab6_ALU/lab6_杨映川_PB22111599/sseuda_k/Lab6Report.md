# Lab 6 Report 
**PB22111599 杨映川**
## T1 Adder
目的：</br>4位超前进位加法器 + 层次扩展成 32 位：1 分
8位超前进位加法器：1 分
8位超前进位加法器 + 层次扩展成 32 位：1 分

四位超前进位加法器：
>       module Adder_LookAhead4 (
>           input                   [ 3 : 0]        a, b,
>           input                   [ 0 : 0]        ci,
>           output                  [ 3 : 0]        s,
>           output                  [ 0 : 0]        co
>       );
>       
>           wire    [3:0] C;
>           wire    [3:0] G;
>           wire    [3:0] P;
>       
>           assign  G = a & b;
>           assign  P = a ^ b;
>       
>           assign  C[0] = G[0] | ( P[0] & ci );
>           assign  C[1] = G[1] | ( P[1] & G[0] ) | ( P[1] & P[0] & ci );
>           assign  C[2] = G[2] | ( P[2] & G[1] ) | ( P[2] & P[1] & G[0] ) | ( P[2] & P[1] & P[0] & ci );
>           assign  C[3] = G[3] | ( P[3] & G[2] ) | ( P[3] & P[2] & G[1] ) | ( P[3] & P[2] & P[1] & G[0] ) | ( P  [3] & P[2] & P[1] & P[0] & ci );
>       
>           assign  s[0] = P[0] ^ ci;
>           assign  s[1] = P[1] ^ C[0];
>           assign  s[2] = P[2] ^ C[1];
>           assign  s[3] = P[3] ^ C[2];
>           assign  co   = C[3];
>       endmodule

4位加法器拼接成32位加法器：
>       module Adder (
>           input                   [31 : 0]        a, b,
>           input                   [ 0 : 0]        ci,
>           output                  [31 : 0]        s,
>           output                  [ 0 : 0]        co
>       );
>       wire    [6:0] cmid;
>       Adder_LookAhead4 adder0(
>           .a(a[3:0]),
>           .b(b[3:0]),
>           .ci(ci),
>           .s(s[3:0]),
>           .co(cmid[0])
>       );
>       
>       Adder_LookAhead4  adder1 (
>           .a(a[7:4]),
>           .b(b[7:4]),
>           .ci(cmid[0]),
>           .s(s[7:4]),
>           .co(cmid[1])
>         );
>       
>         Adder_LookAhead4  adder2 (
>           .a(a[11:8]),
>           .b(b[11:8]),
>           .ci(cmid[1]),
>           .s(s[11:8]),
>           .co(cmid[2])
>         );
>       
>         Adder_LookAhead4  adder3 (
>           .a(a[15:12]),
>           .b(b[15:12]),
>           .ci(cmid[2]),
>           .s(s[15:12]),
>           .co(cmid[3])
>         );
>       
>         Adder_LookAhead4  adder4 (
>           .a(a[19:16]),
>           .b(b[19:16]),
>           .ci(cmid[3]),
>           .s(s[19:16]),
>           .co(cmid[4])
>         );
>       
>         Adder_LookAhead4  adder5 (
>           .a(a[23:20]),
>           .b(b[23:20]),
>           .ci(cmid[4]),
>           .s(s[23:20]),
>           .co(cmid[5])
>         );
>       
>         Adder_LookAhead4  adder6 (
>           .a(a[27:24]),
>           .b(b[27:24]),
>           .ci(cmid[5]),
>           .s(s[27:24]),
>           .co(cmid[6])
>         );
>       
>         Adder_LookAhead4  adder7 (
>           .a(a[31:28]),
>           .b(b[31:28]),
>           .ci(cmid[6]),
>           .s(s[31:28]),
>           .co(co)
>         );
>       // TODO：继续例化 Adder_LookAhead4 模块并正确连接
>       
>       endmodule
仿真波形：
![Alt text](image.png)
8位超前进位加法器：
>       module CAdder_8bits(
>           input       [7:0]   a, b,
>           input       [0:0]   ci,
>           output      [7:0]   s,
>           output      [0:0]   co
>           );
>       
>           wire    [7:0] C;
>           wire    [7:0] G;
>           wire    [7:0] P;
>       
>           assign  G = a & b;
>           assign  P = a ^ b;
>       
>           assign  C[0] = G[0] | ( P[0] & ci );
>           assign  C[1] = G[1] | ( P[1] & G[0] ) | ( P[1] & P[0] & ci );
>           assign  C[2] = G[2] | ( P[2] & G[1] ) | ( P[2] & P[1] & G[0] ) | ( P[2] & P[1] & P[0] & ci );
>           assign  C[3] = G[3] | ( P[3] & G[2] ) | ( P[3] & P[2] & G[1] ) | ( P[3] & P[2] & P[1] & G[0] ) | ( P[3] & P[2] & P[1] & P[0] & ci );
>           assign  C[4] = G[4] | ( P[4] & G[3] ) | ( P[4] & P[3] & G[2] ) | ( P[4] & P[3] & P[2] & G[1] ) | ( P[4] & P[3] & P[2] & P[1] & G[0] ) | ( P[4] & P[3] & P[2] & P[1] & P[0] & ci );
>           assign  C[5] = G[5] | ( P[5] & G[4] ) | ( P[5] & P[4] & G[3] ) | ( P[5] & P[4] & P[3] & G[2] ) | ( P[5] & P[4] & P[3] & P[2] & G[1] ) | ( P[5] & P[4] & P[3] & P[2] & P[1] & G[0] ) | ( P[5] & P[4] & P[3] & P[2] & P[1] & P[0] & ci );
>           assign  C[6] = G[6] | ( P[6] & G[5] ) | ( P[6] & P[5] & G[4] ) | ( P[6] & P[5] & P[4] & G[3] ) | ( P[6] & P[5] & P[4] & P[3] & G[2] ) | ( P[6] & P[5] & P[4] & P[3] & P[2] & G[1] ) | ( P[6] & P[5] & P[4] & P[3] & P[2] & P[1] & G[0] ) | ( P[6] & P[5] & P[4] & P[3] & P[2] & P[1] & P[0] & ci );
>           assign  C[7] = G[7] | ( P[7] & G[6] ) | ( P[7] & P[6] & G[5] ) | ( P[7] & P[6] & P[5] & G[4] ) | ( P[7] & P[6] & P[5] & P[4] & G[3] ) | ( P[7] & P[6] & P[5] & P[4] & P[3] & G[2] ) | ( P[7] & P[6] & P[5] & P[4] & P[3] & P[2] & G[1] ) | ( P[7] & P[6] & P[5] & P[4] & P[3] & P[2] & P[1] & P[0] ) | ( P[7] & P[6] & P[5] & P[4] & P[3] & P[2] & P[1] & P[0] & ci );
>       
>           assign  s[0] = P[0] ^ ci;
>           assign  s[1] = P[1] ^ C[0];
>           assign  s[2] = P[2] ^ C[1];
>           assign  s[3] = P[3] ^ C[2];
>           assign  s[4] = P[4] ^ C[3];
>           assign  s[5] = P[5] ^ C[4];
>           assign  s[6] = P[6] ^ C[5];
>           assign  s[7] = P[7] ^ C[6];
>           assign  co   = C[7];
>       endmodule

8位加法器拼接成32位加法器：
>       module Adderxx (
>           input                   [31 : 0]        a, b,
>           input                   [ 0 : 0]        ci,
>           output                  [31 : 0]        s,
>           output                  [ 0 : 0]        co
>       );
>       
>       wire    [2:0]  cmid;
>       
>       CAdder_8bits adder0(
>           .a(a[7:0]),
>           .b(b[7:0]),
>           .ci(ci),
>           .s(s[7:0]),
>           .co(cmid[0])
>       );
>       
>       CAdder_8bits adder1(
>           .a(a[15:8]),
>           .b(b[15:8]),
>           .ci(cmid[0]),
>           .s(s[15:8]),
>           .co(cmid[1])
>       );
>       
>       CAdder_8bits adder2(
>           .a(a[23:16]),
>           .b(b[23:16]),
>           .ci(cmid[1]),
>           .s(s[23:16]),
>           .co(cmid[2])
>       );
>       
>       CAdder_8bits adder3(
>           .a(a[31:24]),
>           .b(b[31:24]),
>           .ci(cmid[2]),
>           .s(s[31:24]),
>           .co(co)
>       );
>       endmodule
仿真波形：
![Alt text](image-1.png)

## T2 ALU
实现下列操作：
![Alt text](image-2.png)
其中减法运算的实现代码：
>       module AddSub (
>           input                   [ 31: 0]        a, b,
>           output                  [ 31: 0]        out,
>           output                  [ 0 : 0]        co
>       );
>       
>       Adder  fa1(
>           .a(a),
>           .b(~b),
>           .ci(1'B1),
>           .s(out),
>           .co(co)
>       );
>       endmodule
其中比较运算的实现代码：
>       module Comp(
>           input       [31:0]  a, b,
>           output      reg     slt_out,
>           output              sltu_out
>           );
>       
>           wire [31:0] out_sub;
>           wire co;
>           AddSub  AddSub_inst (
>           .a(a),
>           .b(b),
>           .out(out_sub),
>           .co(co)
>         );
>       
>           always @(*) begin
>               if ((a[31] && !b[31])) // neg < pos
>                   slt_out = 1;
>               else if ((!a[31] && b[31])) // pos > neg
>                   slt_out = 0;
>               else begin // same sign
>                   slt_out = out_sub[31]; // the sign of the output
>               end
>           end
>           
>           assign sltu_out = !co;
>       endmodule

其他运算均使用相应运算符号直接实现。</br>
ALU的总实现代码为：
>       module ALU(
>           input                   [31 : 0]        src0, src1,
>           input                   [11 : 0]        sel,
>           output                  [31 : 0]        res
>       );
>       // Write your code here
>       wire [31:0] adder_out;
>       wire [31:0] sub_out;
>       wire [0 :0] slt_out;
>       wire [0 :0] sltu_out;
>       
>       Adder adder(
>           .a(src0),
>           .b(src1),
>           .ci(1'B0),
>           .s(adder_out),
>           .co()
>       );
>       
>       AddSub sub(
>           .a(src0),
>           .b(src1),
>           .out(sub_out),
>           .co()
>       );
>       
>       Comp comp(
>           .a(src0),
>           .b(src1),
>           .sltu_out(sltu_out),
>           .slt_out(slt_out)
>       );
>       
>       wire    [31:0]    and_out = src0 & src1;
>       wire    [31:0]    or_out  = src0 | src1;
>       wire    [31:0]    nor_out = ~(src0 | src1);
>       wire    [31:0]    xor_out = src0 ^ src1;
>       wire    [31:0]    sll_out = src0 << src1[4:0]; // left logic
>       wire    [31:0]    srl_out = src0 >> src1[4:0]; // right logic
>       wire    [31:0]    sra_out = src0 >>> src1[4:0]; // right arithmetic
>       wire    [31:0]    src1_out= src1; // source 1 out
>       
>       // TODO：完成 res 信号的选择
>       assign res =    (sel == 12'h001) ? adder_out    :
>                       (sel == 12'h002) ? sub_out      :
>                       (sel == 12'h004) ? slt_out      :
>                       (sel == 12'h008) ? sltu_out     :
>                       (sel == 12'h010) ? and_out      :
>                       (sel == 12'h020) ? or_out       :
>                       (sel == 12'h040) ? nor_out      :
>                       (sel == 12'h080) ? xor_out      :
>                       (sel == 12'h100) ? sll_out      :
>                       (sel == 12'h200) ? srl_out      :
>                       (sel == 12'h400) ? sra_out      :
>                       (sel == 12'h800) ? src1_out     : 0;
>       
>       // End of your code
>       endmodule

仿真波形：
example 1：`src0 = x0000_ffff, src1 = x0000_ffff`
![Alt text](image-3.png)
example 2: `src0 = xffff_f111, src1 = x0000_0000`
![Alt text](image-4.png)
example 3: `src0 = x0000_0000, src1 = xffff_f111`
![Alt text](image-5.png)

## T*1 Visualized ALU
将ALU的计算结果与七段数码管拼接起来，实现计算结果在数码管的最后一位实时更新显示。其中，用 `sw[5:3]` 与 `sw[2:0]` 分别表示输入 `src0`、`src1`，使用 `sw[7:6]` 代表 `sel` 选择 ALU 运算，输出结果显示在七段数码管上。</br>其中，</br> `sw[7:6]=2'b00` 时表示加法；</br>`sw[7:6]=2'b01` 时表示减法；</br>`sw[7:6]=2'b10` 时表示有符号比较；</br>`sw[7:6]=2'b11` 时表示无符号比较。

首先实现一个迷你ALU，对3位的数字进行符号位扩展：
>       module ALUmini(
>           input                   [2 : 0]        src0, src1,
>           input                   [1 : 0]        sel,
>           output                  [2 : 0]        res
>       );
>       // Write your code here
>       wire [31:0] adder_out;
>       wire [31:0] sub_out;
>       wire [0 :0] slt_out;
>       wire [0 :0] sltu_out;
>       
>       Adder adder(
>           .a({{29{src0[2]}}, src0[2:0]}),
>           .b({{29{src0[2]}}, src1[2:0]}),
>           .ci(1'B0),
>           .s(adder_out),
>           .co()
>       );
>       
>       AddSub sub(
>           .a({{29{src0[2]}}, src0[2:0]}),
>           .b({{29{src1[2]}}, src1[2:0]}),
>           .out(sub_out),
>           .co()
>       );
>       
>       Comp comp( // SEXT
>           .a({{29{src0[2]}}, src0[2:0]}),
>           .b({{29{src1[2]}}, src1[2:0]}),
>           .sltu_out(sltu_out),
>           .slt_out(slt_out)
>       );
>       
>       // TODO：完成 res 信号的选择
>       assign res =    (sel == 2'b00) ? adder_out  :
>                       (sel == 2'b01) ? sub_out    :
>                       (sel == 2'b10) ? slt_out   :
>                       sltu_out;   
>       // End of your code
>       endmodule

其中调用的模块均为前两题使用过的基础模块。

在FPGA上实现效果如下：
example 1：4 + 2 = 6
![Alt text](image-6.png)
example 2：6 - 1 = 5
![Alt text](image-7.png)
example 3：-2 < +1, 输出1
![Alt text](image-8.png)
example 4：4 > 3， 输出0
![Alt text](image-9.png)