#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#define N 512 // 需要根据实际情况调整该数字！
int **Mul(int **pa, int **pb)
{
    int i, j, k, tmp = 0;
    int **pc = (int **)malloc(2 * sizeof(int *));
    for (i = 0; i < 2; i++)
        pc[i] = (int *)malloc(2 * sizeof(int));
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 2; j++)
        {
            tmp = 0;
            for (k = 0; k < 2; k++)
                tmp += pa[i][k] * pb[k][j];
            pc[i][j] = tmp;
        }
    }
    return pc;
}
int **Pluss(int **p0, int **p1, int n)
{
    int i, j;
    int **p = (int **)malloc(n * sizeof(int *));
    for (i = 0; i < n; i++)
        p[i] = (int *)malloc(n * sizeof(int));
    for (i = 0; i < n; i++)
        for (j = 0; j < n; j++)
            p[i][j] = p0[i][j] + p1[i][j];
    return p;
}
int **Minus(int **p0, int **p1, int n)
{
    int i, j;
    int **p = (int **)malloc(n * sizeof(int *));
    for (i = 0; i < n; i++)
        p[i] = (int *)malloc(n * sizeof(int));
    for (i = 0; i < n; i++)
        for (j = 0; j < n; j++)
            p[i][j] = p0[i][j] - p1[i][j];
    return p;
}
int **Strassen(int **pa, int **pb, int n)
{
    int i, j;
    int **pc = (int **)malloc(n * sizeof(int *));
    for (i = 0; i < n; i++)
        pc[i] = (int *)malloc(n * sizeof(int));
    /*base case*/
    if (n == 2)
    {
        pc = Mul(pa, pb);
        return pc;
    }
    /*Break*/
    /*A*/
    int **A11 = (int **)malloc(n / 2 * sizeof(int *));
    for (i = 0; i < n / 2; i++)
        A11[i] = (int *)malloc(n / 2 * sizeof(int));
    for (i = 0; i < n / 2; i++)
        for (j = 0; j < n / 2; j++)
            A11[i][j] = pa[i][j];

    int **A12 = (int **)malloc(n / 2 * sizeof(int *));
    for (i = 0; i < n / 2; i++)
        A12[i] = (int *)malloc(n / 2 * sizeof(int));
    for (i = 0; i < n / 2; i++)
        for (j = 0; j < n / 2; j++)
            A12[i][j] = pa[i][j + n / 2];

    int **A21 = (int **)malloc(n / 2 * sizeof(int *));
    for (i = 0; i < n / 2; i++)
        A21[i] = (int *)malloc(n / 2 * sizeof(int));
    for (i = 0; i < n / 2; i++)
        for (j = 0; j < n / 2; j++)
            A21[i][j] = pa[i + n / 2][j];

    int **A22 = (int **)malloc(n / 2 * sizeof(int *));
    for (i = 0; i < n / 2; i++)
        A22[i] = (int *)malloc(n / 2 * sizeof(int));
    for (i = 0; i < n / 2; i++)
        for (j = 0; j < n / 2; j++)
            A22[i][j] = pa[i + n / 2][j + n / 2];

    /*B*/
    int **B11 = (int **)malloc(n / 2 * sizeof(int *));
    for (i = 0; i < n / 2; i++)
        B11[i] = (int *)malloc(n / 2 * sizeof(int));
    for (i = 0; i < n / 2; i++)
        for (j = 0; j < n / 2; j++)
            B11[i][j] = pb[i][j];

    int **B12 = (int **)malloc(n / 2 * sizeof(int *));
    for (i = 0; i < n / 2; i++)
        B12[i] = (int *)malloc(n / 2 * sizeof(int));
    for (i = 0; i < n / 2; i++)
        for (j = 0; j < n / 2; j++)
            B12[i][j] = pb[i][j + n / 2];

    int **B21 = (int **)malloc(n / 2 * sizeof(int *));
    for (i = 0; i < n / 2; i++)
        B21[i] = (int *)malloc(n / 2 * sizeof(int));
    for (i = 0; i < n / 2; i++)
        for (j = 0; j < n / 2; j++)
            B21[i][j] = pb[i + n / 2][j];

    int **B22 = (int **)malloc(n / 2 * sizeof(int *));
    for (i = 0; i < n / 2; i++)
        B22[i] = (int *)malloc(n / 2 * sizeof(int));
    for (i = 0; i < n / 2; i++)
        for (j = 0; j < n / 2; j++)
            B22[i][j] = pb[i + n / 2][j + n / 2];

    /*Create S's*/
    int **S1 = (int **)malloc(n / 2 * sizeof(int *));
    for (i = 0; i < n / 2; i++)
        S1[i] = (int *)malloc(n / 2 * sizeof(int));
    S1 = Minus(B12, B22, n / 2);

    int **S2 = (int **)malloc(n / 2 * sizeof(int *));
    for (i = 0; i < n / 2; i++)
        S2[i] = (int *)malloc(n / 2 * sizeof(int));
    S2 = Pluss(A11, A12, n / 2);

    int **S3 = (int **)malloc(n / 2 * sizeof(int *));
    for (i = 0; i < n / 2; i++)
        S3[i] = (int *)malloc(n / 2 * sizeof(int));
    S3 = Pluss(A21, A22, n / 2);

    int **S4 = (int **)malloc(n / 2 * sizeof(int *));
    for (i = 0; i < n / 2; i++)
        S4[i] = (int *)malloc(n / 2 * sizeof(int));
    S4 = Minus(B21, B11, n / 2);

    int **S5 = (int **)malloc(n / 2 * sizeof(int *));
    for (i = 0; i < n / 2; i++)
        S5[i] = (int *)malloc(n / 2 * sizeof(int));
    S5 = Pluss(A11, A22, n / 2);

    int **S6 = (int **)malloc(n / 2 * sizeof(int *));
    for (i = 0; i < n / 2; i++)
        S6[i] = (int *)malloc(n / 2 * sizeof(int));
    S6 = Pluss(B11, B22, n / 2);

    int **S7 = (int **)malloc(n / 2 * sizeof(int *));
    for (i = 0; i < n / 2; i++)
        S7[i] = (int *)malloc(n / 2 * sizeof(int));
    S7 = Minus(A12, A22, n / 2);
    for (i = 0; i < n / 2; i++)
        free(A12[i]);
    free(A12);

    int **S8 = (int **)malloc(n / 2 * sizeof(int *));
    for (i = 0; i < n / 2; i++)
        S8[i] = (int *)malloc(n / 2 * sizeof(int));
    S8 = Pluss(B21, B22, n / 2);
    for (i = 0; i < n / 2; i++)
        free(B21[i]);
    free(B21);

    int **S9 = (int **)malloc(n / 2 * sizeof(int *));
    for (i = 0; i < n / 2; i++)
        S9[i] = (int *)malloc(n / 2 * sizeof(int));
    S9 = Minus(A11, A21, n / 2);
    for (i = 0; i < n / 2; i++)
        free(A21[i]);
    free(A21);

    int **S0 = (int **)malloc(n / 2 * sizeof(int *));
    for (i = 0; i < n / 2; i++)
        S0[i] = (int *)malloc(n / 2 * sizeof(int));
    S0 = Pluss(B11, B12, n / 2);
    for (i = 0; i < n / 2; i++)
        free(B12[i]);
    free(B12);

    /*Create P's*/
    int **P1 = (int **)malloc(n / 2 * sizeof(int *));
    for (i = 0; i < n / 2; i++)
        P1[i] = (int *)malloc(n / 2 * sizeof(int));
    P1 = Strassen(A11, S1, n / 2);
    for (i = 0; i < n / 2; i++)
        free(A11[i]);
    free(A11);
    for (i = 0; i < n / 2; i++)
        free(S1[i]);
    free(S1);

    int **P2 = (int **)malloc(n / 2 * sizeof(int *));
    for (i = 0; i < n / 2; i++)
        P2[i] = (int *)malloc(n / 2 * sizeof(int));
    P2 = Strassen(S2, B22, n / 2);
    for (i = 0; i < n / 2; i++)
        free(B22[i]);
    free(B22);
    for (i = 0; i < n / 2; i++)
        free(S2[i]);
    free(S2);

    int **P3 = (int **)malloc(n / 2 * sizeof(int *));
    for (i = 0; i < n / 2; i++)
        P3[i] = (int *)malloc(n / 2 * sizeof(int));
    P3 = Strassen(S3, B11, n / 2);
    for (i = 0; i < n / 2; i++)
        free(B11[i]);
    free(B11);
    for (i = 0; i < n / 2; i++)
        free(S3[i]);
    free(S3);

    int **P4 = (int **)malloc(n / 2 * sizeof(int *));
    for (i = 0; i < n / 2; i++)
        P4[i] = (int *)malloc(n / 2 * sizeof(int));
    P4 = Strassen(A22, S4, n / 2);
    for (i = 0; i < n / 2; i++)
        free(A22[i]);
    free(A22);
    for (i = 0; i < n / 2; i++)
        free(S4[i]);
    free(S4);

    int **P5 = (int **)malloc(n / 2 * sizeof(int *));
    for (i = 0; i < n / 2; i++)
        P5[i] = (int *)malloc(n / 2 * sizeof(int));
    P5 = Strassen(S5, S6, n / 2);
    for (i = 0; i < n / 2; i++)
        free(S5[i]);
    free(S5);
    for (i = 0; i < n / 2; i++)
        free(S6[i]);
    free(S6);

    int **P6 = (int **)malloc(n / 2 * sizeof(int *));
    for (i = 0; i < n / 2; i++)
        P6[i] = (int *)malloc(n / 2 * sizeof(int));
    P6 = Strassen(S7, S8, n / 2);
    for (i = 0; i < n / 2; i++)
        free(S7[i]);
    free(S7);
    for (i = 0; i < n / 2; i++)
        free(S8[i]);
    free(S8);

    int **P7 = (int **)malloc(n / 2 * sizeof(int *));
    for (i = 0; i < n / 2; i++)
        P7[i] = (int *)malloc(n / 2 * sizeof(int));
    P7 = Strassen(S9, S0, n / 2);
    for (i = 0; i < n / 2; i++)
        free(S9[i]);
    free(S9);
    for (i = 0; i < n / 2; i++)
        free(S0[i]);
    free(S0);

    /*Free A's & B's & S's*/
    /*Create C's*/
    int **C11 = (int **)malloc(n / 2 * sizeof(int *));
    for (i = 0; i < n / 2; i++)
        C11[i] = (int *)malloc(n / 2 * sizeof(int));
    C11 = Pluss(P5, P4, n / 2);
    C11 = Minus(C11, P2, n / 2);
    C11 = Pluss(C11, P6, n / 2);
    for (i = 0; i < n / 2; i++)
        free(P6[i]);
    free(P6);

    int **C12 = (int **)malloc(n / 2 * sizeof(int *));
    for (i = 0; i < n / 2; i++)
        C12[i] = (int *)malloc(n / 2 * sizeof(int));
    C12 = Pluss(P1, P2, n / 2);
    for (i = 0; i < n / 2; i++)
        free(P2[i]);
    free(P2);

    int **C21 = (int **)malloc(n / 2 * sizeof(int *));
    for (i = 0; i < n / 2; i++)
        C21[i] = (int *)malloc(n / 2 * sizeof(int));
    C21 = Pluss(P3, P4, n / 2);
    for (i = 0; i < n / 2; i++)
        free(P4[i]);
    free(P4);

    int **C22 = (int **)malloc(n / 2 * sizeof(int *));
    for (i = 0; i < n / 2; i++)
        C22[i] = (int *)malloc(n / 2 * sizeof(int));
    C22 = Pluss(P5, P1, n / 2);
    for (i = 0; i < n / 2; i++)
        free(P5[i]);
    free(P5);
    for (i = 0; i < n / 2; i++)
        free(P1[i]);
    free(P1);
    C22 = Minus(C22, P3, n / 2);
    for (i = 0; i < n / 2; i++)
        free(P3[i]);
    free(P3);
    C22 = Minus(C22, P7, n / 2);
    for (i = 0; i < n / 2; i++)
        free(P7[i]);
    free(P7);

    /*Unification*/
    for (i = 0; i < n / 2; i++)
        for (j = 0; j < n / 2; j++)
            pc[i][j] = C11[i][j];
    for (i = 0; i < n / 2; i++)
        free(C11[i]);
    free(C11);

    for (i = 0; i < n / 2; i++)
        for (j = 0; j < n / 2; j++)
            pc[i][j + n / 2] = C12[i][j];
    for (i = 0; i < n / 2; i++)
        free(C12[i]);
    free(C12);

    for (i = 0; i < n / 2; i++)
        for (j = 0; j < n / 2; j++)
            pc[i + n / 2][j] = C21[i][j];
    for (i = 0; i < n / 2; i++)
        free(C21[i]);
    free(C21);

    for (i = 0; i < n / 2; i++)
        for (j = 0; j < n / 2; j++)
            pc[i + n / 2][j + n / 2] = C22[i][j];
    for (i = 0; i < n / 2; i++)
        free(C22[i]);
    free(C22);

    /*Free P's & C's*/
    return pc;
}
int **Multiplication(int **pa, int **pb, int n)
{
    int i, j, k, tmp;
    int **pc = (int **)malloc(n * sizeof(int *));
    for (i = 0; i < n; i++)
        pc[i] = (int *)malloc(n * sizeof(int));
    for (i = 0; i < n; i++)
        for (j = 0; j < n; j++)
        {
            tmp = 0;
            for (k = 0; k < n; k++)
                tmp += pa[i][k] * pb[k][j];
            pc[i][j] = tmp;
        }
    return pc;
}
int main()
{
    clock_t start, end, startt, endd;
    FILE *fp;
    int i, j, flag;
    int **pa = (int **)malloc(N * sizeof(int *));
    int **pb = (int **)malloc(N * sizeof(int *));
    int **pc = (int **)malloc(N * sizeof(int *));
    for (i = 0; i < N; i++)
    {
        pa[i] = (int *)malloc(N * sizeof(int));
        pb[i] = (int *)malloc(N * sizeof(int));
        pc[i] = (int *)malloc(N * sizeof(int));
    }
    printf("INPUT 1 IF U WANT TO MAKE THE MATRICES BY HAND;\n");
    printf("INPUT 2 IF U ALREADY HAVE MATRICES IN Matrix.txt;\n");
    printf("INPUT 3 IF U WANT RANDOM MATRICES;\n");
    scanf("%d", &flag);
    /*INPUT*/
    if (flag == 1)
    {
        printf("INPUT THE 1ST %dTH ORDER MATRIX:\n", N);
        for (i = 0; i < N; i++) // Input A;
        {
            for (j = 0; j < N; j++)
                scanf("%d", &pa[i][j]);
            // printf("\n");
        }
        printf("\nINPUT THE 2ND %dTH ORDER MATRIX:\n", N);
        for (i = 0; i < N; i++) // Input B;
        {
            for (j = 0; j < N; j++)
                scanf("%d", &pb[i][j]);
            // printf("\n");
        }
        printf("\n");
    }
    if (flag == 2)
    {
        fp = fopen("Matrix.txt", "r");
        for (i = 0; i < N; i++)
        {
            for (j = 0; j < N; j++)
                fscanf(fp, "%d", &pa[i][j]);
            // printf("\n");
        }
        for (i = 0; i < N; i++)
        {
            for (j = 0; j < N; j++)
                fscanf(fp, "%d", &pb[i][j]);
            // printf("\n");
        }
        fclose(fp);
    }
    if (flag == 3)
    {
        int low, up;
        printf("ELEMENTS INSIDE WILL BE LIMITED WITHIN [LOW, UPP),\nINPUT LOW:");
        scanf("%d", &low);
        printf("INPUT UPP:");
        scanf("%d", &up);
        for (i = 0; i < N; i++) // Input A;
        {
            for (j = 0; j < N; j++)
                pa[i][j] = low + rand() % (up - low);
            // printf("\n");
        }
        for (i = 0; i < N; i++) // Input B;
        {
            for (j = 0; j < N; j++)
                pb[i][j] = low + rand() % (up - low);
            // printf("\n");
        }
        printf("\n");
    }
    start = clock();
    pc = Strassen(pa, pb, N);
    end = clock();
    startt = clock();
    pc = Multiplication(pa, pb, N);
    endd = clock();
    printf("STRASSEN COSTS TIME:%f\n", (double)(end - start) / CLOCKS_PER_SEC);
    printf("ORDINARY COSTS TIME:%f\n", (double)(endd - startt) / CLOCKS_PER_SEC);
    printf("THE RESULT:\n");
    for (i = 0; i < N; i++)
        free(pa[i]);
    free(pa);
    for (i = 0; i < N; i++)
        free(pb[i]);
    free(pb);
    // for (i = 0; i < N; i++)
    // {
    //     for (j = 0; j < N; j++)
    //         printf("%d ", pc[i][j]);
    //     printf("\n\n");
    // }
    for (i = 0; i < N; i++)
        free(pc[i]);
    free(pc);
    return 0;
}