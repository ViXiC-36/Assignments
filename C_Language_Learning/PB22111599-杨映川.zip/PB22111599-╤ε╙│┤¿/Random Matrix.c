#include <stdio.h>
#define N 4 // 需要根据实际情况调整该数字！
int main()
{
    int i;
    FILE *fp;
    fp = fopen("Matrix.txt", "w");
    if (fp == NULL)
    {
        printf("NO!");
        return 0;
    }
    for (i = 0; i < N * N; i++)
        fprintf(fp, "%d ", rand() % 10);
    fclose(fp);
    return 0;
}